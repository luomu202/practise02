package com.module;


import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.constant.RegConstant.ADDRESS_REG;

@Data
public class CustomerModel implements Serializable {

    private String id;
    @NotNull
    private String name;
    @NotNull
    private String password;
    private int gender;
    private String nation;
    @Email
    private String email;
    private String iphone;
    @Pattern(regexp = ADDRESS_REG)
    private String address;
    private int level;
    private int status;
}
