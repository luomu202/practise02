package com.module;

import com.domain.AccountDo;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


import java.io.Serializable;
import java.util.Date;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
@Data
public class LoginModel implements Serializable {

    private static final long serialVersionUID = 3886447022415869136L;
    @JsonProperty("nick_name")
//    @Pattern(regexp = "",message = "用户名")
    private String nickName;
    private String iphone;
    private String password;
    private String openId;
    @JsonProperty("fail_count")
    private int failCount;
    @JsonProperty("account_status")
    private int accountStatus;
    private Date loginTime;
    private String role;


    public LoginModel() {
    }

    public LoginModel(AccountDo accountDo) {
        this.failCount = accountDo.getFailCount();
        this.accountStatus = accountDo.getAccountStatus();
        this.loginTime = accountDo.getLoginTime();
        this.iphone = accountDo.getIphone();
        this.nickName = accountDo.getNickName();
        this.role = accountDo.getRole();
    }
}
