package com.example.factory;

import com.example.utils.BeanTools;
import lombok.extern.log4j.Log4j2;

import java.util.Map;


@Log4j2
public class PipelineFactory<T> {

    private  final Map<String,Class<T>> actionMap;

    public PipelineFactory(Map<String, Class<T>> actionMap) {
        this.actionMap = actionMap;
    }

    public Action<T> getInstance(String type) {
        Class<T> clazz = actionMap.get(type);
        if (clazz == null) {
            throw new RuntimeException("action class is null");
        }
        return (Action<T>) BeanTools.getBean(clazz);
    }
}
