package com.annoation;

import com.enums.Roles;

import java.lang.annotation.*;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
/**
 * 权限
 */

public @interface AuthPermission {
    boolean check() default true;

    /**
     * 角色
     * @return
     */
    Roles[] role() default Roles.TOURIST;
}
