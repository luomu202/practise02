package com.example.config;

import org.apache.shardingsphere.api.sharding.standard.PreciseShardingAlgorithm;
import org.apache.shardingsphere.api.sharding.standard.PreciseShardingValue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.Collection;
import java.util.List;

@Configuration
public class ModuloShardingTableAlgorjithm implements PreciseShardingAlgorithm<String> {

    /**
     * 分表数量
     */
    private Integer resourceNum = 2;

    private List<Long> resourceIdList=ApplicationConfig.getResourceIdList();

    private String taskResource = "t_product";


    @Override
    public String doSharding(Collection<String> tableNames, PreciseShardingValue<String> preciseShardingValue) {
        String taskIdStr = preciseShardingValue.getValue();
        if (taskIdStr.length() == 32) {
            for (String each :tableNames) {
                //id为uuid方式
//                /**
//                 * 表是以数字结尾，采用这种方式
//                 */
//                if (each.endsWith(Math.abs(taskIdStr.hashCode() % resourceNum) + "")) {
//                    return each;
//                }
                if (Math.abs(taskIdStr.hashCode() % resourceNum)== 1) {
                    return each;
                }
            }
        }else {
            //id为自增
            long id = Long.parseLong(taskIdStr);
            for (int i = 0; i < resourceIdList.size(); i++) {
                if (id < resourceIdList.get(i)) {
                    return taskResource + "_" + (i+resourceNum);
                }
            }
        }
        throw new UnsupportedOperationException();
    }
}
