package com.controller;

import com.annoation.AuthPermission;
import com.enums.Roles;
import com.module.CustomerModel;
import com.module.LoginModel;
import com.module.Response;
import com.module.ServiceException;
import com.service.UserService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import static com.constant.ErrorConstant.VALIDATED_ERROR;



@Log4j2
@RestController
@RequestMapping("/v1/MemberService/account")
public class CustomerController extends BaseController {

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/create2",method = RequestMethod.POST)
    @AuthPermission( role = Roles.TEACHER,check = true)
    @ResponseBody
    public Response createUser(@Validated @RequestBody CustomerModel customerModel, BindingResult bindingResult) throws ServiceException {
        if (bindingResult.hasErrors()) {
            FieldError fieldError = bindingResult.getFieldError();
            log.error(" bindingResult has error code"+fieldError.getCode()+" message "+fieldError.getDefaultMessage());
             return getErrorResponse(VALIDATED_ERROR, fieldError.getDefaultMessage());
        }
        log.info("create user params "+ customerModel);
        userService.createUser(customerModel);
        return getSuccessResponse();
    }
    @RequestMapping(value = "/create",method = RequestMethod.POST)
    @AuthPermission( role = Roles.TEACHER,check = true)
    @ResponseBody
    public Response createAccount(@Validated @RequestBody LoginModel loginModel, BindingResult bindingResult) throws ServiceException {
        if (bindingResult.hasErrors()) {
            FieldError fieldError = bindingResult.getFieldError();
            log.error(" bindingResult has error code"+fieldError.getCode()+" message "+fieldError.getDefaultMessage());
            return getErrorResponse(VALIDATED_ERROR, fieldError.getDefaultMessage());
        }
        log.info("create user params "+ loginModel);
        userService.createAccount(loginModel);
        return getSuccessResponse();
    }
}
