package com.example.service.impl;

import com.example.dao.standard.AttachDao;
import com.example.module.AttachModule;
import com.example.module.ProductItem;
import com.example.service.AttachService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static com.example.utils.CommonUtils.generateUuid;

@Service
@Log4j2
public class AttachServiceImpl implements AttachService {

    @Autowired
    private AttachDao attachDao;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void createAttach(ProductItem productItem,String productId) {
        List<AttachModule> attachModuleList = new ArrayList<>();
        for (String image : productItem.getImageList()) {
            AttachModule attachModule = new AttachModule();
            attachModule.setId(generateUuid())
                    .setProductId(productId)
                    .setUrl(image)
                    .setFileType(0);
            attachModuleList.add(attachModule);
        }
        AttachModule attachModule = new AttachModule();
        attachModule.setProductId(productId)
                .setUrl(productItem.getSeedUrl())
                .setFileType(1);
        attachModuleList.add(attachModule);
        attachDao.insertAttachList(attachModuleList);
        log.info("insert complete productId "+productId);
    }
}
