package com.renss.spring.aop.privilege.dao.impl;

import org.springframework.stereotype.Repository;

import com.renss.spring.aop.privilege.dao.PersonDao;

@Repository("personDao")
public class PersonDaoImpl implements PersonDao{

	public void savePerson() {
		System.out.println("personDao开始执行savePerson方法。。。");
	}

	public void updatePerson() {
		System.out.println("personDao开始执行updatePerson方法。。。");
		
	}

}
