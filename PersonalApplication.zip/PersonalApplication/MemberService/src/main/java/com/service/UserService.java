package com.service;

import com.module.LoginModel;
import com.module.ServiceException;
import com.module.CustomerModel;

public interface UserService {
    void createUser(CustomerModel customerModel) throws ServiceException;

    void createAccount(LoginModel loginModel);
}
