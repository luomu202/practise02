package com.example.anno;

import java.lang.annotation.*;

/**
 * @author luomu
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface ActionType {

    String value() default "";
}
