package com.constant;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public interface CommonConstant {

    String UTF8 = "UTF-8";

    /**
     *
     */
    String REQUEST_PATTERN = "/";

    String REQUEST_SEPARATE = ".";
}
