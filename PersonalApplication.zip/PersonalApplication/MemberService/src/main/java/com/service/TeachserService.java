package com.service;

import java.util.List;
import java.util.Map;


public interface TeachserService {
    List<Map> getTeacherList();

    void getTeacherListFile();
}
