package com.handler;

import com.module.Error;
import com.module.Response;
import com.module.ServiceException;
import lombok.extern.log4j.Log4j2;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import static com.enums.ResponseStatus.FAILED;


@ControllerAdvice
@Log4j2
public class DefaultExceptionHandler {

    @ExceptionHandler(value = ServiceException.class)
    @ResponseBody
    public Response serviceExceptionHandler(ServiceException se) {
        Response response = new Response();
        response.setResult(null);
        response.setError(new Error(se.getError().getCode(),se.getError().getMessage()));
        return response;
    }
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public Response serviceExceptionHandler(Exception ve) {
        log.error("error rise up "+ve);
        Response response = new Response();
        response.setResult(null);
        response.setStatus(FAILED.getName());
        response.setError(new Error("cm.100","参数错误"));
        return response;
    }

}
