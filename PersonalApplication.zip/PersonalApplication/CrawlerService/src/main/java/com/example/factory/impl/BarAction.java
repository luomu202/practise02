package com.example.factory.impl;

import com.example.anno.ActionType;
import com.example.constant.RegexConstant;
import com.example.enums.PageTypes;
import com.example.factory.Action;
import com.example.module.ProductItem;
import com.example.service.AttachService;
import com.example.service.ProductService;
import com.example.service.TeacherService;
import com.example.utils.CommonUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@ActionType("bar")
@Component
@Log4j2
public class BarAction implements Action<ProductItem> {

    @Autowired
    private ProductService productService;

    @Autowired
    private AttachService attachService;

    @Autowired
    private TeacherService teacherService;

    @Override
    public void doAction(ProductItem productItem) {
        String teacherId = teacherService.saveTeacher(productItem);
        productItem.setTeacherId(teacherId);
        String productId = productService.saveProductByType(productItem, PageTypes.BAR.getName());
        if (productId == null) {
            return;
        }
        //插入附件
        attachService.createAttach(productItem, productId);
    }
}
