package com.example.service;

import com.example.module.TeacherModule;

import java.util.List;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public interface ProductShardingService {
    List<TeacherModule> selectTeacherList();

}
