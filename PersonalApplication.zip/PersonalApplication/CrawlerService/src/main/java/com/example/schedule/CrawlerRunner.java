package com.example.schedule;

import com.example.task.JobProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

import static com.example.constant.CommonConstant.*;

/**
 * @author luomu
 * spring启动后运行
 */
@Component
public class CrawlerRunner implements CommandLineRunner {

    @Autowired
    private JobProcessor jobProcessor;

    @Override
    public void run(String... args) {
        jobProcessor.startProcess(getStartPageList());
    }

    private String[] getStartPageList() {
        ArrayList<String> pageList = new ArrayList<>();
//        pageList.add(PING_START_PAGE);
//        pageList.add(PING_START_PAGE_ANIME);
//        pageList.add(TAOHUA_START_PAGE);
//        pageList.add(BAR_START_PAGE_GAO);
        pageList.add(BAR_START_PAGE);
        return pageList.toArray(new String[pageList.size()]);
    }
}
