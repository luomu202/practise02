package com.example.module;

import java.util.Date;

public class TeacherModule {

    private String id;
    private String name;
    private String alias;
    private Integer priority;
    private Date createTime;
    private Date updateTime;
    private int status = 1;

    public TeacherModule() {
    }

    public String getId() {
        return id;
    }

    public TeacherModule setId(String id) {
        this.id = id;
        return this;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public TeacherModule setCreateTime(Date createTime) {
        this.createTime = createTime;
        return this;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public TeacherModule setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
        return this;
    }

    public int getStatus() {
        return status;
    }

    public TeacherModule setStatus(int status) {
        this.status = status;
        return this;
    }

    public String getName() {
        return name;
    }

    public TeacherModule setName(String name) {
        this.name = name;
        return this;
    }

    public String getAlias() {
        return alias;
    }

    public TeacherModule setAlias(String alias) {
        this.alias = alias;
        return this;
    }

    public int getPriority() {
        return priority;
    }

    public TeacherModule setPriority(int priority) {
        this.priority = priority;
        return this;
    }

}
