package com.dao;

import com.module.Response;
import com.module.TeacherModel;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


public interface TeacherDao {

    Response createTeacher();

    void insertTeacher(TeacherModel teacherModel);

    List<Map> getTeachserList();

}
