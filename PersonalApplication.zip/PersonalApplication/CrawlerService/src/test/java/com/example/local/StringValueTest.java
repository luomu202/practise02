package com.example.local;

import org.junit.Test;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class StringValueTest {
    @Test
    public void parseString() {
        String init = "【影片名稱】：HEYZO-2477婚約者をネトラレ！～同窓会でお持ち帰りされちゃった～–白杞りり";
        String substring = init.substring(7);
        System.out.println(init);
    }
    @Test
    public void parseContent() {
        String init =" 【影片名稱】：【個人撮影】初撮り★ひとみ23歳スレンダーボディのＯＬ！初めてのカメラの前でのＳＥＸは生中出しからお掃除フェラまでさせられます！ 【出       演】：素人 【影片格式】：mp4 【影片大小】：1.42GB 【影片時長】 :00:49:16 【是否有碼】：無碼 【發 行  日】 ：2021-03-07 【種子期限】：長期做種 【品       番】 :fc2ppv_1714773 【影圖預覽】：     ";
        String s = init.replaceAll("：", "#")
                .replaceAll(":","#");
//                .replaceAll(" ","#")
//                .replaceAll(" ","#");
        String[] split = s.split("#");
        int length = split.length;
        String s1 = split[11].substring(0,split[11].length()-7);
        String s2 = split[8].substring(0, split[8].length() - 9);

        System.out.println(init);
    }

    @Test
    public void dateTest() throws ParseException, UnsupportedEncodingException {
        String a = "2021-01-31 00:00:00";
        String b = "2021-01-31 00:00:00";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date aTime = dateFormat.parse(a);
        Date bTime = dateFormat.parse(b);
        boolean before = aTime.before(bTime);
        System.out.println(before);
    }

    @Test
    public void animeParseTest(){
        String content = "<p>【影片名稱】：姉恋 スキ・キライ・ダイスキ。 ＃2<br> 【影片格式】：mkv<br> 【影片大小】：556M<br> 【有／無碼】：無<br> 【清晰程度】：清晰<br> 【預覽圖片】：</p>";
        String[] itemList = content.replace("<p>", "")
                .replace("</p>", "")
                .split("<br>");
        String a = itemList[0].substring(7);
        String b = itemList[1].substring(8);
        String c = itemList[2].substring(8);
        String d = itemList[3].substring(8);
        System.out.println("1212");

    }
    @Test
    public void barParseTest() {
        String s = " 【影片名称】：無理矢理AVに出演させられた美人マネージャー 天海つばさ 【出演女优】：天海つばさ 【影片格式】：MP4 【影片大小】：6.64GB 【是否有码】：无码[有损去除马赛克] 【种子期限】：5种或健康度1000 【下载工具】：比特彗星 比特精灵 uTorrent QBittorrent 迅雷极速版【请不要用迅雷官方版下载，官方版本已经被屏蔽】 【影片预览】：看不到图请挂代理或点右键显示图片    磁力链接  ";
        String s1 = s.replaceAll(" ", "");
        String[] split = s1.split("：");
        System.out.println("123");
    }
    @Test
    public void barParseTest2() {
        System.out.println("123");
        try {
            String s = "032121_001-1pon  モデルコレクション 天緒まい";
            String s1 = s.replaceAll(" ", "3");

            System.out.println("123");
        } catch (Exception e) {
            System.out.println("123");
        }

    }
}
