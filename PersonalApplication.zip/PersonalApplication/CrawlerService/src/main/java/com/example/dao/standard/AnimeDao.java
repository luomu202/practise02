package com.example.dao.standard;

import com.example.module.AnimeModule;
import org.apache.ibatis.annotations.Param;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public interface AnimeDao {
    void saveAnime(AnimeModule animeModule);

    int selectCountByName(@Param("name") String name);
}
