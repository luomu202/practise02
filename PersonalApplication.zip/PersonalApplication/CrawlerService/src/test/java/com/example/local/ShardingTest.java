package com.example.local;

import org.junit.Test;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public class ShardingTest {

    @Test
    public void algorithmTest() {
        String id = "685b74062040d34a27a8577c91754755";
        String name ="t_product_taohua";
        String name2 ="t_product_bar";
        int abs = Math.abs(id.hashCode() % 2);
        int nameabs = Math.abs(name.hashCode() % 2);
        int name2abs = Math.abs(name2.hashCode() % 2);
        System.out.println("abs rusult is "+abs);
        System.out.println("nameabs rusult is "+nameabs);
        System.out.println("name2abs rusult is "+name2abs);
    }
}
