package com.util;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SheetUtils {

    /**
     * 定义标题栏样式
     *
     * @param workBook
     * @return
     */
    public static XSSFCellStyle createHeaderStyle(XSSFWorkbook workBook) {
        //生成一个样式
        XSSFCellStyle style = workBook.createCellStyle();
        //设置表头样式
        style.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setAlignment(HorizontalAlignment.CENTER);
        //开启自动换行
        style.setWrapText(true);
        //生产一个字体
        XSSFFont font = workBook.createFont();
        font.setColor(HSSFColor.HSSFColorPredefined.VIOLET.getIndex());
        font.setFontHeightInPoints((short) 12);
        font.setBold(true);
        //把字体应用到当前样式
        style.setFont(font);
        return style;
    }

    public static XSSFCellStyle createContentStyle(XSSFWorkbook workBook) {
        //生成并设置内容样式
        XSSFCellStyle style = workBook.createCellStyle();
        style.setFillForegroundColor(HSSFColor.HSSFColorPredefined.LIGHT_YELLOW.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        XSSFDataFormat format = workBook.createDataFormat();
        style.setDataFormat(format.getFormat("@"));
        //生成另一个字体
        XSSFFont font = workBook.createFont();
        font.setColor(HSSFColor.HSSFColorPredefined.BLUE.getIndex());
        font.setFontHeightInPoints((short) 12);
        font.setBold(false);
        style.setFont(font);
        return style;
    }

    /**
     * @param cell
     * @return
     */
    public static String getCellValue(Cell cell) {
        if (cell == null) {
            return "";
        }
        String cellValue;
        switch (cell.getCellType()) {
            case STRING:
                cellValue = cell.getRichStringCellValue().getString().trim();
                break;
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    cellValue = org.jboss.resteasy.util.DateUtil.formatDate(cell.getDateCellValue(), "yyyy-MM-dd");
                } else {
                    cellValue = MathUtils.getRealStringOfDouble(cell.getNumericCellValue());
                }
                break;
            case BOOLEAN:
                cellValue = String.valueOf(cell.getBooleanCellValue()).trim().toUpperCase();
                break;
            case FORMULA:
                cellValue = cell.getCellFormula();
                break;
            default:
                cellValue = "";
        }
        return cellValue;
    }
}
