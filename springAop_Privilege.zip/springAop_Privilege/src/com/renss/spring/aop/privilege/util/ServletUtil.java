package com.renss.spring.aop.privilege.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class ServletUtil {
	private ServletUtil(){}
	
	public static HttpServletRequest getHttpServletRequest(){
		return ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
	}
	
	public static HttpServletResponse getHttpServletResponse(){
		return (HttpServletResponse) getHttpServletRequest().getAttribute("respons");
	}
	
	public static HttpSession getHttpSession(){
		return getHttpServletRequest().getSession();
	}
	
	
}
