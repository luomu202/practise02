package com.example.local;

import com.example.constant.RegexConstant;
import com.example.utils.CommonUtils;
import org.junit.Test;

public class RegexTest {

    @Test
    public void isMatch() {
        String s1 = "http://www.psk6.cc/rihan/page/1";

        String s2 = "https://www.pinse5.com/donghua/page/1";

        String s3 = "http://thz28.com/forum-181-1.html";

        boolean match1 = CommonUtils.match(RegexConstant.PING_URL_REGEX, s1);
        boolean match2 = CommonUtils.match(RegexConstant.PING_URL_REGEX, s2);
        boolean match3 = CommonUtils.match(RegexConstant.TAOHUA_URL_REGEX, s3);

        System.out.println(match1);
        System.out.println(match2);
        System.out.println(match3);
    }
}
