package com.domain;

import com.constant.AccountConstant;
import com.enums.Roles;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.module.LoginModel;
import com.util.CommonUtils;
import lombok.Data;

import java.util.Date;

/**
 * 对应账户表
 *
 * @author luomu
 * @description
 * @date 2018-09-07
 */
@Data
public class AccountDo {
    private String id;
    private String userId;
    @JsonProperty("open_id")
//    @SerializedName("open_id")
    private String openId;
    private String nickName;
    private String iphone;
    private String password;
    private String salt;
    private int accountStatus;
    private int failCount;
    private String role;
    private Date loginTime;
    private Date createTime;
    private Date updateTime;
    private String ip;
    private int status;

    public AccountDo() {
    }

    public AccountDo(LoginModel loginModel) {
        this.id = CommonUtils.genrerateUuid();
        this.openId = loginModel.getOpenId();
        this.nickName = loginModel.getNickName();
        this.iphone = loginModel.getIphone();
        this.status = 1;
        this.failCount = 0;
        this.accountStatus = AccountConstant.ACCOUNT_NORMAL;
        this.role = Roles.PURCHASER.getName();
    }
}
