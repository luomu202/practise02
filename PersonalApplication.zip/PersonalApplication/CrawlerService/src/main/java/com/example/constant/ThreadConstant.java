package com.example.constant;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public interface ThreadConstant {
    ThreadLocal<String> DEFEATTHREADLOCAL = new InheritableThreadLocal<>();
}
