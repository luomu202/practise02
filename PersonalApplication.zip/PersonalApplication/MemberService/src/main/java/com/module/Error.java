package com.module;

import com.constant.ErrorConstant;

import java.io.Serializable;

/**
 * @author Administrator
 */

public class Error implements Serializable {
    private static final long serialVersionUID = 8703167276903953229L;
    private String code;
    private String message;

    public Error() {
    }

    public Error(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public Error(String message) {
        this.code= ErrorConstant.DEFAULT_ERROR_CODE;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
