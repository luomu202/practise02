package com.example.utils;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang.StringUtils;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
@Log4j2
public class ExceptionLogUtils {

    public static void dealWithExceptionLog(Exception se) {
        StackTraceElement[] stackTrace = se.getStackTrace();
        String result = null;
        for (StackTraceElement frame : stackTrace) {
            if (frame.getClassName().contains("com.example")) {
                log.error("unexpected error rise up class name " + frame.getClassName());
                log.error("unexpected error rise up method name " + frame.getMethodName());
                log.error("unexpected error rise up line number " + frame.getLineNumber());
                result = se.toString();
            }
        }
        if (StringUtils.isEmpty(result)) {
            result=se.getStackTrace()[0].toString();
        }
        log.error("unexpected error rise up message " + result);
    }
}
