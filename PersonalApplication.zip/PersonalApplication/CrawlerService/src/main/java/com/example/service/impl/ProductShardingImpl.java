package com.example.service.impl;

import com.example.dao.shard.ProductShardingDao;
import com.example.module.TeacherModule;
import com.example.service.ProductShardingService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
@Service
@Log4j2
public class ProductShardingImpl implements ProductShardingService {

    @Autowired
    private ProductShardingDao productShardingDao;

    @Override
    public List<TeacherModule> selectTeacherList() {
        List<TeacherModule> list= productShardingDao.selectTeacherList();
        log.info("get teacher List success");
        return list;
    }
}
