package com.example.factory;

import org.springframework.stereotype.Component;
import us.codecraft.webmagic.Page;

@Component
public interface MyPageProcessor<T> {
    public void process(Page page) ;
}
