package com.example.handler;

import com.example.module.Error;
import com.example.module.Response;
import com.example.module.ServiceException;
import com.example.utils.JsonUtils;

import static com.example.enums.ResponseStatus.FAILED;
import static com.example.enums.ResponseStatus.SUCCESS;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public class ResponseHandler {

    public Response getSuccessResponse(Object obj) {
        Response<String> response = new Response<>();
        String result = JsonUtils.toJson(obj);
        response.setResult(result);
        response.setStatus(SUCCESS.getName());
        return response;
    }

    public static Response getSuccessResponse() {
        Response<String> response = new Response<>();
        response.setResult(null);
        response.setStatus(SUCCESS.getName());
        return response;
    }
    public static Response getErrorResponse(String message) {
        Response<String> response = new Response<>();
        response.setResult(null);
        response.setStatus(FAILED.getName());
        response.setError(new Error(message));
        return response;
    }

    public static Response getErrorResponse(String code,String message) throws ServiceException {
        Response<String> response = new Response<>();
        response.setResult(null);
        response.setStatus(FAILED.getName());
        response.setError(new Error(code,message));
        return response;
    }
}
