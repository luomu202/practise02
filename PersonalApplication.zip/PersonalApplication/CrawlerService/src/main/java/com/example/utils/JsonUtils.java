package com.example.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import lombok.extern.log4j.Log4j2;

import java.io.IOException;
import java.text.Normalizer;

@Log4j2
public class JsonUtils {

    public static final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd hh:mm:ss").disableHtmlEscaping().create();

    /**
     * 单例
     * @param
     * @return
     */
    public static Gson getInstance() {
        return gson;
    }
    public static String toJson(Object object) {
        return gson.toJson(object);
    }

    public static <T> T fromJson(Object object, Class<T> clz) throws IOException {
        return new ObjectMapper().readValue(CommonUtils.decode(Normalizer.normalize(CommonUtils.encode(getInstance().toJson(object)), Normalizer.Form.NFKC)).getBytes(), clz);
    }

    public static <T> T fromJson(Object obj, TypeReference<T> type) throws IOException {
        ObjectMapper om = new ObjectMapper();
        om.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
        om.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return  om.readValue(CommonUtils.decode(Normalizer.normalize(CommonUtils.encode(getInstance().toJson(obj)), Normalizer.Form.NFKC)), type);
    }
}
