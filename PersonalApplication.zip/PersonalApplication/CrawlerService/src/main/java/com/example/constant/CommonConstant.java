package com.example.constant;

public interface CommonConstant {

    String PING_REJECT_ITEM = "本站已经稳定运行四年";

    String TAOHUA_REJECT_ITEM = "论坛一直免费非商业性运做着";

    String PING_START_PAGE = "http://www.psk6.cc/rihan/page/1";

    String PING_START_PAGE_ANIME = "https://www.pinse5.com/donghua/page/1";

    String TAOHUA_START_PAGE = "http://thz28.com/forum-181-1.html";

    String TAOHUA_DNS = "http://thz28.com/";

    String BAR_START_PAGE = "https://www.98asrwq.xyz/forum-36-1.html";

    String BAR_START_PAGE_GAO = "https://www.98asrwq.xyz/forum.php?mod=forumdisplay&fid=103&typeid=481&typeid=481&filter=typeid&page=1";

    int GRP_TIME = 7;

    Long QUEUE_EXCUTETIME = 5000L;
}
