package com.module;

import java.io.Serializable;

import static com.constant.ErrorConstant.DEFAULT_ERROR_CODE;


public class ServiceException extends RuntimeException implements Serializable {

    private static final long serialVersionUID = -7826240236240275724L;
    private final Error error = new Error();

    public ServiceException(Error expertXml) {
        super(expertXml.getMessage());
        this.error.setCode(expertXml.getCode());
        this.error.setMessage(expertXml.getMessage());
    }

    public ServiceException(String errorCode, String message){
        super(message);
        this.error.setCode(errorCode);
        this.error.setMessage(message);
    }
    public ServiceException(String message){
        super(message);
        this.error.setCode(DEFAULT_ERROR_CODE);
        this.error.setMessage(message);
    }

    public Error getError() {
        return error;
    }

    @Override
    public String toString() {
        return "ServiceException{" +
                "error=" + error.getCode() +",reason="+ error.getMessage()+
                '}';
    }
}
