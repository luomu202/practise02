package com.example.utils;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

    public static Date getDateFromString(String date,String format) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat.parse(date);
    }
    public static Date getDateFromStringQuietly(String date) {
        Date result;

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            result = dateFormat.parse(date);
            return result;
        } catch (Exception e) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                result = dateFormat.parse(date);
                return result;
            } catch (Exception parseException) {
                return new Date();
            }
        }
    }
}
