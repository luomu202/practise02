package com.example.factory.impl;

import com.example.module.DefeatModule;
import com.example.service.DefeatService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.example.utils.CommonUtils.generateUuid;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
@Component
@Log4j2
public class BaseProcessor {

    @Autowired
    private DefeatService defeatService;

    public void handlerDefeatPage(String pageUrl) {
        log.error("parse page fail");
        int affectRoes = defeatService.updateRetryTimes(pageUrl);
        if (affectRoes == 0) {
            DefeatModule defeatModule = new DefeatModule();
            defeatModule.setId(generateUuid())
                    .setUrl(pageUrl);
            defeatService.insertNewPage(defeatModule);
        }
    }
}
