package com.service.impl;

import com.constant.ErrorConstant;
import com.dao.TeacherDao;
import com.module.ServiceException;
import com.module.TeacherModel;
import com.service.TeachserService;
import com.util.CommonUtils;
import com.util.SheetUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.serialization.ValidatingObjectInputStream;
import org.apache.commons.lang.StringUtils;


import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.xssf.usermodel.*;
import org.jboss.resteasy.util.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Log4j2
public class TeachserServiceImpl implements TeachserService {

    @Autowired
    private TeacherDao td;

    @Override
    public List<Map> getTeacherList() {
        List<Map> teachserList = td.getTeachserList();

        return teachserList;
    }

    @Override
    public void getTeacherListFile() {
        List<Map> teachserList = td.getTeachserList();
//        ArrayList<TeacherModel> teList = JsonUtils.from
        Map<String, String> header = new HashMap<>();
        byte[] bytes = new byte[1024];
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
            ValidatingObjectInputStream ois = new ValidatingObjectInputStream(bis);
            ois.accept(TeacherModel.class);
            ois.accept(ArrayList.class);
            ois.readObject();
            List<TeacherModel> expTemp = new ArrayList<>();
            header.put("errorMessage", "错误信息");
            header.put("id", "id");
            header.put("name", "名称");
            header.put("count", "下载次数");
            header.put("status", "是否有效");
            String fileName = "各种老师";
            exportExcel(header, expTemp, "getOptions", 20, fileName);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void exportExcel(Map<String, String> header, List<TeacherModel> expData, String specialMethodName, int fixHeaderRe, String fileName) {
        //声明工作簿
        XSSFWorkbook workbook = new XSSFWorkbook();
        //生产表格
        XSSFSheet sheet = workbook.createSheet("工作项列表");
        //设置表格默认列宽度 16个字节
        sheet.setDefaultColumnWidth((short) 16);
        XSSFCellStyle headerStyle = SheetUtils.createHeaderStyle(workbook);
        XSSFCellStyle contentStyle = SheetUtils.createContentStyle(workbook);
        //什么一个画图的顶级管理器
        XSSFDrawing drawingPatriarch = sheet.createDrawingPatriarch();
        //产生表格标题行
        XSSFRow row = sheet.createRow(0);
        row.setHeight((short) 30);
        List<String> fieldList = new ArrayList<>();
        Iterator<Map.Entry<String, String>> iterator = header.entrySet().iterator();
        int column = 0;
        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            XSSFCell cell = row.createCell(column++);
            cell.setCellStyle(headerStyle);
            XSSFRichTextString text = new XSSFRichTextString(entry.getValue());
            cell.setCellValue(text);
            //保存一份字段代码名称
            fieldList.add(entry.getKey());
        }
        produceData(expData, workbook, sheet, contentStyle, drawingPatriarch, fieldList, specialMethodName, fixHeaderRe);
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletResponse response = servletRequestAttributes.getResponse();
        fileName = DateUtil.formatDate(new Date(), "yyyy-MM-dd hh-mm-ss") + ".xlsx";
        response.setHeader("Content-Type", "application/octet-stream;charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + CommonUtils.encode(fileName));
        response.setHeader("Access-Control-Expose-Headers", "Content-Disposition");
        OutputStream out = null;
        try {
            out = response.getOutputStream();
            workbook.write(out);
            log.info("expert xml succeed");
        } catch (IOException e) {
            log.error("expert xml failed reason " + e.getMessage());
            throw new ServiceException(ErrorConstant.EXPERT_XML);
        } finally {
            IOUtils.closeQuietly(out);
            IOUtils.closeQuietly(workbook);

        }

    }

    private void produceData(List<TeacherModel> expData, XSSFWorkbook workbook,
                             XSSFSheet sheet, XSSFCellStyle contentStyle, XSSFDrawing drawingPatriarch,
                             List<String> fieldList, String specialMethodName, int fixHeaderRe) {

        XSSFRow row;
        Iterator<TeacherModel> it = expData.iterator();
        int rowNum = 1;
        while (it.hasNext()) {
            row = sheet.createRow(rowNum);
            TeacherModel exercise = it.next();
            for (int i = 0; i < fieldList.size() - fixHeaderRe; i++) {
                XSSFCell cell = row.createCell(i);
                cell.setCellStyle(contentStyle);
                String fieldName = fieldList.get(i);
                String getMethodName = "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
                setCellDate(getMethodName, cell, i, exercise, row, workbook, drawingPatriarch, sheet, rowNum, new HashMap<>(), specialMethodName);
                if (StringUtils.isNotEmpty(specialMethodName)) {

                }
            }
        }
    }

    private void setCellDate(String getMethodName, XSSFCell cell, int i, TeacherModel exercise,
                             XSSFRow row, XSSFWorkbook workbook, XSSFDrawing drawingPatriarch,
                             XSSFSheet sheet, int rowNum, HashMap<Object, Object> map, String specialMethodName) {
        Object value;
        try {
            Class<? extends TeacherModel> t = exercise.getClass();
            Method method = t.getMethod(getMethodName);
            value = method.invoke(exercise);
        } catch (NoSuchMethodException e) {
            log.error("methodName is not current " + e.getMessage());
            throw new ServiceException(e.getMessage());
        } catch (IllegalAccessException e) {
            log.error("an error arise up " + e.getMessage());
            throw new ServiceException(e.getMessage());
        } catch (InvocationTargetException e) {
            log.error("an error arise up " + e.getMessage());
            throw new ServiceException(e.getMessage());
        }
        if (value == null) {
            return;
        }
        String txtValue = null;
        if (value instanceof Boolean) {
            log.error("");
        } else if (value instanceof Date) {
            Date date = (Date) value;
            SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            txtValue = sf.format(date);
        } else if (value instanceof byte[]) {
            //图片
            row.setHeightInPoints(60);
            sheet.setColumnWidth(i, (short) (35.7 * 80));
            byte[] bs = (byte[]) value;
//            XSSFChildAnchor anchor = new XSSFChildAnchor(0, 0, 1023, 255, (short) 6, rowNum, (short) 6, rowNum);
//            anchor.setAnchorType(ClientAnchor.AnchorType.MOVE_DONT_RESIZE);
//            drawingPatriarch.createPicture(anchor, workbook.addPicture(bs, XSSFWorkbook.PICTURE_TYPE_BMP));

        } else if (value instanceof List) {
            map.put(specialMethodName, value);
        } else {
            txtValue = value.toString();
        }
        if (txtValue != null) {
            setCellTxtValue(cell, txtValue);
        }
    }

    private void setCellTxtValue(XSSFCell cell, String txtValue) {
        if (CommonUtils.match("^//d+(//.d+)?$", txtValue)) {
            cell.setCellValue(Double.parseDouble(txtValue));
        } else {
            XSSFRichTextString xs = new XSSFRichTextString(txtValue);
            cell.setCellValue(xs);
        }

    }
}
