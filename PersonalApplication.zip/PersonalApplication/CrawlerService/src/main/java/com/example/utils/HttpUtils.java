package com.example.utils;

import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import java.net.URISyntaxException;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public class HttpUtils {


    private CloseableHttpClient getHttpClient(String url) throws URISyntaxException {
        //创建HttpClient对象
        CloseableHttpClient httpClient = HttpClients.createDefault();
        //创建URIBuilder
        URIBuilder uriBuilder = new URIBuilder(url);
        //设置参数

        //创建HttpGet对象，设置url访问地址
        HttpGet httpGet = new HttpGet(uriBuilder.build());
        return null;
    }
}
