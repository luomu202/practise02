package com.scheudle;

import com.dao.TeacherDao;
import com.module.TeacherModel;
import com.util.CommonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ScheduleTask {

    @Autowired
    private TeacherDao teacherDao;


//    @Scheduled(cron ="*/5 * * * * ?")
    private void insertSchedule() {
        String id = CommonUtils.genrerateUuid();
        TeacherModel teacherModel = new TeacherModel(id,"上原結衣",1,"japan",1);
        teacherDao.insertTeacher(teacherModel);
    }
}
