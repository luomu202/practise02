package com.renss.spring.aop.privilege.aspect;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;

import com.renss.spring.aop.privilege.annotation.AnnotationParse;
import com.renss.spring.aop.privilege.domain.Person;
import com.renss.spring.aop.privilege.domain.Privilege;
import com.renss.spring.aop.privilege.util.ServletUtil;

/**
 * AOP切面类，通过通知accessMethod结合自定义注解@PrivilegeInfo判断用户是否对方法具有执行权限
 * 此处采用环绕通知（环绕通知可以控制方法是否执行）
 * @author renss
 * @date 2017-09-13
 *
 */
public class AccessTargetMethod {

	/**
	 * 
	 * @param joinPoint
	 * @return
	 * @throws Throwable
	 */
	public Object accessMethod(ProceedingJoinPoint joinPoint) throws Throwable{
		//此处通过打印出来的信息可以发现，该方式获取的是接口中的方法
//		Signature mm = joinPoint.getSignature();
//		System.out.println("方法类型说明：" + mm.getDeclaringType());
		
		MethodSignature methodSignature = (MethodSignature)joinPoint.getSignature();
		
		//此方式获取出来的Method指的是接口中的方法，当判断是否有某注解时，也判断的是接口方法中是否存在此注解，而不是判断实现方法。
//		Method interfaceMethod = methodSignature.getMethod();
//		boolean isPrivilegeInfo = interfaceMethod.isAnnotationPresent(PrivilegeInfo.class);
//		System.out.println("isPrivilegeInfo：" + isPrivilegeInfo);
		
		String name = methodSignature.getMethod().getName();
		Class[] parameterTypes = methodSignature.getParameterTypes();
		//通过方法名及参数列表获取目标方法
		Method method = joinPoint.getTarget().getClass().getMethod(name, parameterTypes);
		String[] privileges = AnnotationParse.parse(method);
		if(privileges != null){
			if(isPrivailege(privileges)){//如果用户权限包含所有的方法执行权限，则放行，否则返回无权限执行
				return joinPoint.proceed();
			}
			//无权限时直接跳转到无权限提示页面
			ServletUtil.getHttpServletResponse().sendRedirect(ServletUtil.getHttpServletRequest().getContextPath() + 
					"/noPrivilege.jsp");
			return null;
		}else{
			return joinPoint.proceed();//如果目标方法没有权限限制，直接放行
		}
	}

	/**
	 * 判断对方法是否有执行权限
	 * @param privaileges 注解中的方法执行权限
	 * @return true:有权限
	 * 		   false:没有权限
	 */
	private boolean isPrivailege(String[] privaileges) {
		List<String> privailegeList = new ArrayList<String>();
		List<Privilege> userPrivilege = ((Person)ServletUtil.getHttpSession().getAttribute("person")).getPrivileges();
		for(Privilege privilege : userPrivilege){
			privailegeList.add(privilege.getName());
		}
		return privailegeList.containsAll(Arrays.asList(privaileges));
	}
}
