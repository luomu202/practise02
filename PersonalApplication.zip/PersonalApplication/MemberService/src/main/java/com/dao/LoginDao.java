package com.dao;

import com.domain.AccountDo;
import org.apache.ibatis.annotations.Param;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public interface LoginDao {
    /**
     * 查询用户数量
     * @param userName
     * @return
     */
    int queryUserCount(@Param("user_name") String userName);

    /**
     * 查询用户信息
     * @param nickName
     * @return
     */
    AccountDo queryUserInfo(@Param("nickName") String nickName);

    /**
     * 更新用户信息
     * @param updateAccountDo
     * @return
     */
    int updateUserInfo(AccountDo updateAccountDo);
}
