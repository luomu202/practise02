package com.renss.spring.aop.privilege.dao;

public interface PersonDao {

	void savePerson();

	void updatePerson();

}
