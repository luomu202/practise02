package com.renss.spring.aop.privilege.service;


public interface PersonService {
	
	public String savePerson();
	
	public void updatePerson();
}
