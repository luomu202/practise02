package com.example.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ItemList {

    private List<Map<String,String>> itemList =new ArrayList<>();
    private int totalCount;

    public List<Map<String, String>> getItemList() {
        return itemList;
    }

    public ItemList setItemList(List<Map<String, String>> itemList) {
        itemList = itemList;
        return this;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public ItemList setTotalCount(int totalCount) {
        totalCount = totalCount;
        return this;
    }
}
