package com.feign.impl;

import com.feign.MemberFeign;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public class MemberFeignImpl implements MemberFeign {
    @Override
    public Object checkPermission(String cookie, String checkUrl) {
        return null;
    }
}
