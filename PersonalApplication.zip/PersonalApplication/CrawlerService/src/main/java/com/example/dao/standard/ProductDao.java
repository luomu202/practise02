package com.example.dao.standard;

import com.example.module.ProductModule;
import org.apache.ibatis.annotations.Param;

import java.util.Date;


public interface ProductDao {

    int selectCountByLicence(@Param("licence") String licence);

    Date selectBeforeGapPubTime(@Param("type") String type, @Param("day") int grpTime);

    void insertNewProductByType(@Param("productModule") ProductModule productModule,@Param("type") String type);
}
