package com.example.module;

import java.util.Date;

public class ProductModule {

    private String id;
    private String teacherId;
    private String licence;
    private String title;
    private String description;
    private String url;
    private String type;
    private String size;
    private int cavalry;
    private Date publishTime;
    private Date createTime;
    private Date updateTime;
    private int status = 1;



    public ProductModule() {
    }

    public Date getPublishTime() {
        return publishTime;
    }

    public ProductModule setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
        return this;
    }

    public String getTeacherId() {
        return teacherId;
    }

    public ProductModule setTeacherId(String teacherId) {
        this.teacherId = teacherId;
        return this;
    }

    public String getSize() {
        return size;
    }

    public ProductModule setSize(String size) {
        this.size = size;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public ProductModule setTitle(String title) {
        this.title = title;
        return this;
    }

    public String getLicence() {
        return licence;
    }

    public ProductModule setLicence(String licence) {
        this.licence = licence;
        return this;
    }

    public String getType() {
        return type;
    }

    public ProductModule setType(String type) {
        this.type = type;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public ProductModule setDescription(String description) {
        this.description = description;
        return this;
    }

    public String getUrl() {
        return url;
    }

    public ProductModule setUrl(String url) {
        this.url = url;
        return this;
    }

    public int getCavalry() {
        return cavalry;
    }

    public ProductModule setCavalry(int cavalry) {
        this.cavalry = cavalry;
        return this;
    }

    public String getId() {
        return id;
    }

    public ProductModule setId(String id) {
        this.id = id;
        return this;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public ProductModule setCreateTime(Date createTime) {
        this.createTime = createTime;
        return this;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public ProductModule setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
        return this;
    }

    public int getStatus() {
        return status;
    }

    public ProductModule setStatus(int status) {
        this.status = status;
        return this;
    }
}
