package com.renss.spring.aop.privilege.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.renss.spring.aop.privilege.annotation.PrivilegeInfo;
import com.renss.spring.aop.privilege.dao.PersonDao;
import com.renss.spring.aop.privilege.service.PersonService;

@Service("personService")
public class PersonServiceImpl implements PersonService{
	
	@Resource(name="personDao")
	private PersonDao personDao;
	
	@PrivilegeInfo({"save","update"})
	public String savePerson(){
		System.out.println("personService开始执行savePerson方法。。。");
		personDao.savePerson();
		return "abcde";
	}
	
	@PrivilegeInfo({"security","save","update"})
	public void updatePerson(){
		System.out.println("personService开始执行updatePerson方法。。。");
		personDao.updatePerson();
	}

}
