package com.example.factory.impl;

import com.example.anno.ActionType;
import com.example.constant.RegexConstant;
import com.example.enums.PageTypes;
import com.example.factory.Action;
import com.example.module.ProductItem;
import com.example.service.AttachService;
import com.example.service.ProductService;
import com.example.service.TeacherService;
import com.example.utils.CommonUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@ActionType("pingse")
@Component
@Log4j2
public class PskAction implements Action<ProductItem> {

    @Autowired
    private ProductService productService;

    @Autowired
    private AttachService attachService;

    @Autowired
    private TeacherService teacherService;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void doAction(ProductItem productItem) {
        String pageUrl = productItem.getPageUrl();
        String productId = null;
        if (CommonUtils.match(RegexConstant.ANIME_URL_REGEX, pageUrl)) {
            productId = productService.saveAnime(productItem);
        }else {
            String teacherId = teacherService.saveTeacher(productItem);
            productItem.setTeacherId(teacherId);
            productId = productService.saveProductByType(productItem, PageTypes.PINGSE.getName());
        }
        if (productId == null) {
            return;
        }
        //插入附件
        attachService.createAttach(productItem, productId);
    }
}
