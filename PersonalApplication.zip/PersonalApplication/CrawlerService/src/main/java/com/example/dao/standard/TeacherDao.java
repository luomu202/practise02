package com.example.dao.standard;

import com.example.module.TeacherModule;
import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface TeacherDao {
    void insetNewTeacher(TeacherModule teacherModule);

    int selectCountByName(@Param("name") String teacher);

    String selectTeacherIdByName(@Param("name") String teacher);

    void updateTeacherTimes( @Param("id") String teacherId);

    List<TeacherModule> getPrepareTeacherList();

    void updateTeacherPriority(@Param("id") String id, @Param("priority") Integer priority);

    TeacherModule getTeacherById(@Param("id")String id);
}
