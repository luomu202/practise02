package com.example.service;

import com.example.module.DefeatModule;

import java.util.List;

public interface DefeatService {
    void createDefeatRecord(String pageUrl);

    void insertNewPage(DefeatModule defeatModule);

    int updateRetryTimes(String pageUrl);

    List<String> getDefeateRecord();

    void setDefeatStatus(List<String> urls ,Integer status);
}
