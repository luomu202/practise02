package com.constant;

import com.module.Error;

public interface ErrorConstant {

    String DEFAULT_ERROR_CODE = "DEV_CM_250";

    String VALIDATED_ERROR = "DEV_CM_251";

    Error EXPERT_XML = new Error("DEV_CM_252","导出文件失败");

    Error USER_NOT_EXIST = new Error("DEV_CM_253", "用户不存在");

    Error USER_WRONG_ACCOUNT = new Error("DEV_CM_254", "账号或密码错误");
}
