package com.example.dao.standard;

import com.example.module.AttachModule;

import java.util.List;

public interface AttachDao {

    void insertAttachList(List<AttachModule> attachDaoList);
}
