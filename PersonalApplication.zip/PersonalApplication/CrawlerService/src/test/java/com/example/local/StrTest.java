package com.example.local;

import org.junit.Test;

public class StrTest {
    @Test
    public void barStrTest() {
                System.out.println("123");
        try {
            String s = "032121_001-1pon  モデルコレクション 天緒まい";
            String s1 = s.replaceAll(" ", "3");
            String[] s2 = s.split(" ");
            System.out.println("1768323");
        } catch (Exception e) {
            System.out.println("123");
        }
    }

    @Test
    public void barParseTest() {
        String s = " 【影片名称】：無理矢理AVに出演させられた美人マネージャー 天海つばさ 【出演女优】：天海つばさ 【影片格式】：MP4 【影片大小】：6.64GB 【是否有码】：无码[有损去除马赛克] 【种子期限】：5种或健康度1000 【下载工具】：比特彗星 比特精灵 uTorrent QBittorrent 迅雷极速版【请不要用迅雷官方版下载，官方版本已经被屏蔽】 【影片预览】：看不到图请挂代理或点右键显示图片    磁力链接  ";
        String s1 = s.replaceAll(" ", "");
        String[] split = s1.split("：");
        System.out.println("123");
    }
}
