package com.example.config;

import com.mysql.jdbc.jdbc2.optional.MysqlXADataSource;
import lombok.Data;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.jta.atomikos.AtomikosDataSourceBean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Data
@Configuration
public class DataSourceConfig {
    /**
     * @Value("注入")
     */
    private Integer maxTotal = 200;
    private Integer initialSize = 50;
    private Integer maxWaitMills = 500;
    private Integer timeBetweenEvictionRunsMillis = 30000;

    /**
     * 分布式事务管理
     * @param dataSourceProperties
     * @param resourceName
     * @return
     */
    public DataSource getAtomikosDataSourceBean(DataSourceProperties dataSourceProperties, String resourceName) {
        MysqlXADataSource mysqlXADataSource = new MysqlXADataSource();
        mysqlXADataSource.setUrl(dataSourceProperties.getUrl());
        mysqlXADataSource.setUser(dataSourceProperties.getUsername());
        mysqlXADataSource.setPassword(dataSourceProperties.getPassword());

        //创建atomikos全局事务
        AtomikosDataSourceBean atomikosDataSourceBean = new AtomikosDataSourceBean();
        atomikosDataSourceBean.setXaDataSource(mysqlXADataSource);
        atomikosDataSourceBean.setUniqueResourceName(resourceName);
        atomikosDataSourceBean.setTestQuery("SELECT 1");
        atomikosDataSourceBean.setMaxPoolSize(maxTotal);
        atomikosDataSourceBean.setMinPoolSize(initialSize);
        atomikosDataSourceBean.setMaintenanceInterval(timeBetweenEvictionRunsMillis);
        atomikosDataSourceBean.setBorrowConnectionTimeout(maxWaitMills);
        return atomikosDataSourceBean;
    }
}
