package com.example.service;

import com.example.module.ProductItem;

public interface ProductService {

    String saveAnime(ProductItem productItem);

    String saveProductByType(ProductItem productItem, String name);
}
