package com.example.dao.shard;

import com.example.module.TeacherModule;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ProductShardingDao {

    List<TeacherModule> selectTeacherList();

}
