package com.Feign;

import com.Feign.impl.TestFeignFallBack;
import com.module.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "shopingService",fallbackFactory = TestFeignFallBack.class)
public interface TestFeign {

    @RequestMapping(value = "v3/create",consumes = "application/json;charset=UTF-8",method = RequestMethod.POST)
    public Response requestTest(@RequestBody String params, @RequestHeader String sign);
}
