package com.service.impl;

import com.constant.CommonConstant;
import com.constant.ErrorConstant;
import com.dao.LoginDao;
import com.domain.AccountDo;
import com.module.LoginModel;
import com.module.ServiceException;
import com.service.LoginService;
import com.util.DateUtils;
import com.util.MD5Utils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.session.Session;
import org.crazycake.shiro.RedisManager;
import org.crazycake.shiro.RedisSessionDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.Date;

import static com.constant.AccountConstant.*;
import static com.constant.CommonConstant.THIRTY_MINUTES;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
@Log4j2
@Service
public class LoginServiceImpl implements LoginService {

    @Autowired
    private LoginDao loginDao;

    @Autowired
    private RedisSessionDAO redisSessionDAO;

    @Override
    public LoginModel loginByUserName(LoginModel loginModel) {
        //默认用户名不重复
        log.info("login by userName " + loginModel.getNickName());
        AccountDo accountDo = loginDao.queryUserInfo(loginModel.getNickName());
        if (accountDo == null) {
            log.error("userInfo is empty");
            throw new ServiceException(ErrorConstant.USER_NOT_EXIST);
        }
        // 先退出， 再登录
        SecurityUtils.getSubject().logout();
        return this.doLogin(accountDo, loginModel.getPassword());
    }

    @Override
    public Boolean validationName(String userName) {
        //TODO 解码
        int count = loginDao.queryUserCount(userName);
        if (count > 0) {
            log.info("userName is duplicated " + userName);
            return false;
        }
        return true;
    }

    /**
     * @param accountDo
     * @param realPassword
     * @return LoginModel
     */
    @Transactional(rollbackFor = Exception.class)
    public LoginModel doLogin(AccountDo accountDo, String realPassword) {
        if (accountDo == null || StringUtils.isEmpty(accountDo.getId())) {
            log.error("userInfo is empty");
            throw new ServiceException(ErrorConstant.USER_WRONG_ACCOUNT);
        }
        LoginModel loginModel = new LoginModel(accountDo);
        AccountDo updateAccountDo = new AccountDo();
        updateAccountDo.setId(accountDo.getId());
        //锁定半小时
        if (DateUtils.getDatePoor(new Date(), accountDo.getLoginTime()) >= THIRTY_MINUTES) {
            updateAccountDo.setAccountStatus(ACCOUNT_NORMAL);
            updateAccountDo.setFailCount(0);
            //更新账号的锁定状态
            if (loginDao.updateUserInfo(updateAccountDo) > 0) {
                //重置账号状态属性
                accountDo.setAccountStatus(ACCOUNT_NORMAL);
                accountDo.setFailCount(0);
            }
        }
        if (accountDo.getAccountStatus() == ACCOUNT_DISUSE) {
            log.error("current user account has been shutoff");
            throw new ServiceException("您的账号已被停用");
        }
        if (accountDo.getAccountStatus() == ACCOUNT_LOCKED) {
            log.error("current user account has been locked");
            throw new ServiceException("账号已被锁定，请半小时后重新登录，或者联系管理员处理");
        }
        if (accountDo.getFailCount() > 5) {
            //密码输错5次，停用账号半小时
            updateAccountDo.setAccountStatus(ACCOUNT_LOCKED);
            loginDao.updateUserInfo(updateAccountDo);
            throw new ServiceException("密码连续错误5次，账号已被锁定，请半小时后重新登录，或者联系管理员处理");
        }
        if (!StringUtils.isEmpty(realPassword)) {
            String password = MD5Utils.getPassword(accountDo.getSalt(), realPassword);
            if (!accountDo.getPassword().equals(password)) {
                // 更新failcount + 1
                updateAccountDo.setFailCount(accountDo.getFailCount() + 1);
                loginDao.updateUserInfo(updateAccountDo);
                throw new ServiceException("用户名或者密码有误，错误次数：" + updateAccountDo.getFailCount());
            }
//            设置加密后的密码返回前端？
//            userEntity.setLoginPasswd(password);
            //缓存不保存用户密码
            accountDo.setPassword(null);
        }
        this.shiroLogin(accountDo);
        // 登录成功，更新failcount重置为0、 最后登录时间
        updateAccountDo.setFailCount(0);
        loginDao.updateUserInfo(updateAccountDo);
        //密码返回空
        loginModel.setPassword(null);
        return loginModel;
    }

    /**
     * 组装token，登录，将用户信息缓存到redis
     *
     * @param accountDo
     */
    private void shiroLogin(AccountDo accountDo) {
        accountDo.setSalt(null);
        // 组装token
        UsernamePasswordToken token = new UsernamePasswordToken(accountDo.getNickName(), accountDo.getPassword().toCharArray());
        Session session = SecurityUtils.getSubject().getSession();
//        user.setToken(session.getId().toString());
        session.setAttribute(CommonConstant.SSO_USER, accountDo);
        // shiro登陆验证
        SecurityUtils.getSubject().login(token);
    }




    @Override
    public Object checkPermission(HttpServletRequest request, String cookie, String checkUrl) {
        AccountDo accountDo = this.getUserInfo(request, cookie);


        return accountDo;
    }

    public AccountDo getUserInfo(HttpServletRequest request, String cookie) {

        // 获取登录用户信息，判断是否登录 -- 默认使用request 获取cookie方式
        Session session = SecurityUtils.getSubject().getSession();
        AccountDo accountDo = (AccountDo) session.getAttribute(CommonConstant.SSO_USER);
        if(null == accountDo || StringUtils.isEmpty(accountDo.getId())) {

            String token = request.getParameter("token");
            if(org.springframework.util.StringUtils.isEmpty(token) && !org.springframework.util.StringUtils.isEmpty(cookie)) {
                token = cookie;
            }

            if(!StringUtils.isEmpty(token) && !token.contains("JSESSIONID") && !"undefined".equals(token)) {
                // log.info("默认从cookie获取用登录信息失败，尝试根据token获取==>" + token);
                RedisManager redisManager = redisSessionDAO.getRedisManager();
                Session s = (Session)deserialize(redisManager.get(this.getByteKey(redisSessionDAO.getKeyPrefix(), token)));
                if(null != s && null != s.getAttribute(CommonConstant.SSO_USER)) {
                    accountDo = (AccountDo) s.getAttribute(CommonConstant.SSO_USER);
                }
                if(null == accountDo || StringUtils.isEmpty(accountDo.getId())) {
                    return null;
                }
            } else {
                return null;
            }
        }
        accountDo.setPassword(null);
        return accountDo;
    }

    /**
     * RedisSessionDAO里面的方法
     * @param keyPrefix
     * @param sessionId
     * @return
     */
    private byte[] getByteKey(String keyPrefix, Serializable sessionId){
        String preKey = keyPrefix + sessionId;
        return preKey.getBytes();
    }

    public static Object deserialize(byte[] bytes) {
        Object result = null;
        if (isEmpty(bytes)) {
            return null;
        } else {
            try {
                ByteArrayInputStream byteStream = new ByteArrayInputStream(bytes);

                try {
                    ObjectInputStream objectInputStream = new ObjectInputStream(byteStream);

                    try {
                        result = objectInputStream.readObject();
                    } catch (ClassNotFoundException var5) {
                        throw new Exception("Failed to deserialize object type", var5);
                    }
                } catch (Throwable var6) {
                    throw new Exception("Failed to deserialize", var6);
                }
            } catch (Exception var7) {
                log.error("Failed to deserialize", var7);
            }

            return result;
        }
    }
    public static boolean isEmpty(byte[] data) {
        return data == null || data.length == 0;
    }
}
