package com.constant;

public interface CommonConstant {
    /**
     * 转换decimal指定精度(6)
     */
    String PRECISION_SIX = "#.000000";
    /**
     * 锁定时间
     */
    int THIRTY_MINUTES = 30;

    String UTF8 = "UTF-8";

    String JSESSIONID = "JSESSIONID";

    String TOKEN = "token";

    String SSO_USER = "sso_account";

}
