package com.example.service;

import com.example.module.ProductItem;

public interface AttachService {
    void createAttach(ProductItem productItem,String productId);
}
