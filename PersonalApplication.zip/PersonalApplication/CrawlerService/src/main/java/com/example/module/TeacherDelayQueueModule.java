package com.example.module;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public class TeacherDelayQueueModule implements Delayed {


    private String id;
    /**
     *消息内容
     */
    private Integer priority;
    //创建时刻的时间
    /**
     * 延迟时长，这个是必须的属性因为要按照这个判断延时时长。
     */
    private long start = System.currentTimeMillis();

    private long excuteTime;

    public TeacherDelayQueueModule() {
    }


    public TeacherDelayQueueModule(TeacherModule item) {
        this.id=item.getId();
    }

    /**
     * 延迟任务是否到时就是按照这个方法判断如果返回的是负数则说明到期
     * 否则还没到期
     * @param unit
     * @return
     */
    @Override
    public long getDelay(TimeUnit unit) {
        return unit.convert((start + this.excuteTime) - System.currentTimeMillis(), TimeUnit.MILLISECONDS);
    }

    /**
     * 比较时间，以最接近执行时间的任务，排在最前面
     * @param delayed
     * @return
     */
    @Override
    public int compareTo(Delayed delayed) {
        TeacherDelayQueueModule msg = (TeacherDelayQueueModule) delayed;
        return (int)(((start + this.excuteTime) - System.currentTimeMillis()) -((msg.start + msg.excuteTime) - System.currentTimeMillis())) ;
    }

    public String getId() {
        return id;
    }

    public TeacherDelayQueueModule setId(String id) {
        this.id = id;
        return this;
    }

    public Integer getPriority() {
        return priority;
    }

    public TeacherDelayQueueModule setPriority(Integer priority) {
        this.priority = priority;
        return this;
    }

    public long getStart() {
        return start;
    }

    public TeacherDelayQueueModule setStart(long start) {
        this.start = start;
        return this;
    }

    public long getExcuteTime() {
        return excuteTime;
    }

    public TeacherDelayQueueModule setExcuteTime(long excuteTime) {
        this.excuteTime = excuteTime;
        return this;
    }
}
