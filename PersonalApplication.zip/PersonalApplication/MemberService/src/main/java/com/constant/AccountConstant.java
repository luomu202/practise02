package com.constant;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public interface AccountConstant {

    /**
     * 账户删除
     */
    int ACCOUNT_DELETE = 0;
    /**
     * 账户正常
     */
    int ACCOUNT_NORMAL = 1;
    /**
     * 账户停用
     */
    int ACCOUNT_DISUSE=2;
    /**
     *账户锁定
     */
    int ACCOUNT_LOCKED=3;

}
