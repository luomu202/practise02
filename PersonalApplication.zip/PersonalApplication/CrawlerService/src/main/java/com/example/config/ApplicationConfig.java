package com.example.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@Configuration
public class ApplicationConfig {


    private static List<Long> resourceIdList;

    public static List<Long> getResourceIdList() {
        return resourceIdList;
    }



    @Value("spring.sharding.resource.list")
    public static void setResourceIdList(List<String> resourceIdList) {
        ApplicationConfig.resourceIdList = resourceIdList.stream().map(Long::valueOf).collect(Collectors.toList());
    }
}
