package com.example.task;

import com.example.constant.RegexConstant;
import com.example.enums.PageTypes;
import com.example.factory.Action;
import com.example.factory.PipelineFactory;
import com.example.module.ProductItem;

import com.example.service.DefeatService;
import com.example.utils.CommonUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.pipeline.Pipeline;

import static com.example.constant.RegexConstant.BAR_URL_REGEX;
import static com.example.utils.CommonUtils.match;


@Log4j2
@Component
public class ProductPipeline implements Pipeline {

    @Autowired
    private PipelineFactory<ProductItem> pipelineFactory;

    @Autowired
    private DefeatService defeatService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void process(ResultItems resultItems, Task task) {
        ProductItem productItem = resultItems.get("productItem");
        if (productItem == null) {
            return;
        }
        String pageUrl = productItem.getPageUrl();
        String type = "";
        if (CommonUtils.match(RegexConstant.PING_URL_REGEX, pageUrl)) {
            type = PageTypes.PINGSE.getName();
        } else if (CommonUtils.match(RegexConstant.TAOHUA_URL_REGEX, pageUrl)) {
            type = PageTypes.TAOHUA.getName();
        }else if (match(BAR_URL_REGEX,pageUrl)) {
            type = PageTypes.BAR.getName();
        }
        Action<ProductItem> action = pipelineFactory.getInstance(type);
        try {
            action.doAction(productItem);
        } catch (Exception e) {
            defeatService.createDefeatRecord(productItem.getPageUrl());
        }
    }
}
