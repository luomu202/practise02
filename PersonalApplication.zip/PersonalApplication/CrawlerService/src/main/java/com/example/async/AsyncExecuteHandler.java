package com.example.async;

import com.example.config.ArtistConfig;
import com.example.constant.CommonConstant;
import com.example.module.TeacherDelayQueueModule;
import com.example.module.TeacherModule;
import com.example.service.DefeatService;
import com.example.service.TeacherService;
import com.example.task.JobProcessor;
import com.example.utils.ExceptionLogUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
@Component
@Log4j2
public class AsyncExecuteHandler {

    @Autowired
    private TeacherService teacherService;

    @Autowired
    private DefeatService defeatService;

    @Autowired
    private JobProcessor jobProcessor;

    @Autowired
    private ArtistConfig artistConfig;

    private final DelayQueue<TeacherDelayQueueModule> queue = new DelayQueue<>();

    @Async
    public void setTeacherPriority() {
        log.info("setTeacherPriority start");
        List<TeacherModule> teacherList = teacherService.getPrepareTeacherList();
        if (teacherList == null && teacherList.size() == 0) {
            log.info("set teacher priority is end size is empty");
            return;
        }
        teacherList.forEach(item -> {
            TeacherDelayQueueModule teacherDelayQueueModule = new TeacherDelayQueueModule();
            teacherDelayQueueModule.setId(item.getId()).setExcuteTime(CommonConstant.QUEUE_EXCUTETIME);
            if (artistConfig.getFirstPriority().contains(item.getName())) {
                teacherDelayQueueModule.setPriority(1);
            } else if (artistConfig.getSecondPriority().contains(item.getName())) {
                teacherDelayQueueModule.setPriority(2);
            } else {
                teacherDelayQueueModule.setPriority(5);
            }
            queue.offer(teacherDelayQueueModule);
        });
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                log.info("queue start time " + System.currentTimeMillis());
                teacherService.setTeacherPriority(queue);
            } catch (InterruptedException e) {
                ExceptionLogUtils.dealWithExceptionLog(e);
            }
        });
        executorService.shutdown();
    }

    @Async
    public void failedPageProcess() {
        log.info("defeat page retry process start");
        //获取失败页面
        List<String> defeatPage= defeatService.getDefeateRecord();
        //更新状态
        //TODO 通过threadlocal 传递参数避免多次更新数据库，失败重试成功需要更新状态-子线程
        defeatService.setDefeatStatus(defeatPage,0);
        jobProcessor.startProcess(defeatPage.toArray(new String[defeatPage.size()]));
    }
}
