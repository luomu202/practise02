package com.util;

import java.text.DecimalFormat;

public class DecimalUtils {
    /**
     *  double转换指定精度String
     * @return
     */
    public static String getStringFromDouble(double from ,String precision) {
        DecimalFormat decimalFormat = new DecimalFormat(precision);
        return decimalFormat.format(from);

    }
}
