package com.example.utils;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang.StringUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.Normalizer;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Log4j2
public class CommonUtils {

    public static String generateUuid() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    public static String decode(String params) {
        String decode="";
        try {
             decode = URLDecoder.decode(params, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            log.error("decode failed reason "+e.getMessage());
        }
        return decode;
    }

    public static String encode(String params) {
        String decode="";
        try {
            decode = URLEncoder.encode(params, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            log.error("encode failed reason "+e.getMessage());
        }
        return decode;
    }

    public static boolean match(String reg, String result) {
        if (StringUtils.isEmpty(reg)||StringUtils.isEmpty(result)) {
            log.error("reg is empty or result is empty");
            return false;
        }
        Pattern p = Pattern.compile(reg);
        String normalize = Normalizer.normalize(result, Normalizer.Form.NFKC);
        Matcher matcher = p.matcher(normalize);
        return matcher.matches();
    }

    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> key) {
        Set<Object> map =ConcurrentHashMap.newKeySet();
        return t -> map.add(key.apply(t));
    }
}
