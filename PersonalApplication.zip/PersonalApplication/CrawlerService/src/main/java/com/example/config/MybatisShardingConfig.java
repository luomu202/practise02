package com.example.config;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.shardingsphere.api.config.sharding.ShardingRuleConfiguration;
import org.apache.shardingsphere.api.config.sharding.TableRuleConfiguration;
import org.apache.shardingsphere.api.config.sharding.strategy.StandardShardingStrategyConfiguration;
import org.apache.shardingsphere.core.constant.properties.ShardingPropertiesConstant;
import org.apache.shardingsphere.shardingjdbc.api.ShardingDataSourceFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

@Configuration
@MapperScan(basePackages = "com.example.dao.shard",sqlSessionTemplateRef = "sqlSessionTemplateSharding")
public class MybatisShardingConfig {

    @Autowired
    private DataSourceConfig dataSourceConfig;

    /**
     * @Value注入
     * @return
     */
    private Integer shardingNum = 20;

    /**
     * 分表数据源配置
     * @return
     */
    @Bean(name = "shardingDataSourceProperties")
    @ConfigurationProperties(prefix = "spring.datasource.sharding")
    public DataSourceProperties shardingDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean("shardingDataSource")
    public DataSource getDataSource(
            @Qualifier("shardingDataSourceProperties") DataSourceProperties dataSourceProperties
    ) throws SQLException {
        ShardingRuleConfiguration shardingRuleConfiguration = new ShardingRuleConfiguration();
        //配置分片规则
        shardingRuleConfiguration.getTableRuleConfigs().add(resourceRuleConfig());
        return ShardingDataSourceFactory.createDataSource(createDataSourceMap(dataSourceProperties), shardingRuleConfiguration, creteProperties());
    }


    @Bean("sqlSessionFactorySharding")
    public SqlSessionFactory sqlSessionFactory(@Qualifier("shardingDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean sfb = new SqlSessionFactoryBean();
        sfb.setDataSource(dataSource);
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        sfb.setMapperLocations(resolver.getResources("classpath:/mapper/**.xml"));
        sfb.setConfigLocation(resolver.getResource("classpath:mybatis-config.xml"));
        return sfb.getObject();
    }

    @Bean("sqlSessionTemplateSharding")
    public SqlSessionTemplate shardingSqlSessionTemplate(
            @Qualifier("sqlSessionFactorySharding") SqlSessionFactory sqlSessionFactory
    ) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    /**
     * 原主表 t_job_task_resource 分表t_job_task_resource_0直到 t_job_task_resource_19
     * @return
     */
    private TableRuleConfiguration resourceRuleConfig() {

//        TableRuleConfiguration tableRuleConfiguration = new TableRuleConfiguration("t_job_task_resource",
//                "ds0.t_job_task_resource_$->{0.."+(shardingNum-1)+"}");
//        tableRuleConfiguration.setTableShardingStrategyConfig(
//                new StandardShardingStrategyConfiguration("job_id",new ModuloShardingTableAlgorjithm()));


        //inline表达式
        TableRuleConfiguration tableRuleConfiguration = new TableRuleConfiguration("t_product",
                "ds0.t_product_$->{['taohua','bar']}");
        tableRuleConfiguration.setTableShardingStrategyConfig(
                new StandardShardingStrategyConfiguration("id",new ModuloShardingTableAlgorjithm()));
        return tableRuleConfiguration;
    }

    private Map<String, DataSource> createDataSourceMap(DataSourceProperties dataSourceProperties) {
        Map<String, DataSource> result = new HashMap<>(1);
        result.put("ds0", dataSourceConfig.getAtomikosDataSourceBean(dataSourceProperties, "shardingDataSource"));
        return result;
    }

    private Properties creteProperties() {
        Properties properties = new Properties();
        properties.put(ShardingPropertiesConstant.SQL_SHOW.getKey(), true);
        return properties;
    }

}
