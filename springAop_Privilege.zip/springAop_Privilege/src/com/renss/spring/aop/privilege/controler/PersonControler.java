package com.renss.spring.aop.privilege.controler;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.renss.spring.aop.privilege.service.PersonService;

@Controller
@RequestMapping("/person")
public class PersonControler {
	@Resource(name="personService")
	PersonService personService;
	
	@RequestMapping("/savePerson")
	public ModelAndView savePerson(){
		ModelAndView mv = new ModelAndView("success");
		System.out.println("personAction开始执行savePerson方法。。。");
		Object obj = personService.savePerson();
		System.out.println("返回值：" + obj);
		return mv;
	}
	
	@RequestMapping("/updatePerson")
	public ModelAndView updatePerson(){
		ModelAndView mv = new ModelAndView("success");
		personService.updatePerson();
		System.out.println("personAction开始执行updatePerson方法。。。");
		return mv;
	}

}
