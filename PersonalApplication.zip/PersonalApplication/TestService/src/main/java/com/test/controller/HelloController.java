package com.test.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
@RestController
@RequestMapping(value = "/v1/testservice")
public class HelloController {
    @RequestMapping(value = "/hello",method = RequestMethod.GET)
    public String geth() {
        return "hello";
    }
}
