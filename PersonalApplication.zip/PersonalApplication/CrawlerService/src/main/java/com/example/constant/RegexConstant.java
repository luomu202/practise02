package com.example.constant;

public interface RegexConstant {

    String IS_CAVALRY_REGEX = "^.*(無碼|無|无|无码|无碼)+.*$";

    String FILE_SIZE_REGEX = "^M|MB|m|mb$";

    String PING_URL_REGEX = "^(http|https?)://(.*/rihan/.*)|(.*\\.pinse5\\.com/donghua.*)$";

    String ANIME_URL_REGEX = "^(http|https?)://.*\\.pinse5\\.com/donghua.*$";

    String TAOHUA_URL_REGEX = "^(http|https?)://thz28\\.com.*$";

    String BAR_URL_REGEX = "^(http|https?)://.*\\.98asrwq\\.xyz/.*$";

    String HE_REGECT_REGEX = "^(.*日本無碼.*)|(.*新片首發.*)|(.*中文字幕.*)$";

    String NUMBER_REGEX = "^\\d*$";
}
