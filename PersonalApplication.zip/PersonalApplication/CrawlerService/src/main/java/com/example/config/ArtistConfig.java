package com.example.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@PropertySource(value = {"classpath:artists/artists.properties"}, ignoreResourceNotFound = true,encoding = "UTF-8")
@ConfigurationProperties(prefix = "artists")
public class ArtistConfig {

    private List<String> firstPriority = new ArrayList<>();

    private List<String> secondPriority = new ArrayList<>();


    public List<String> getFirstPriority() {
        return firstPriority;
    }

    public void setFirstPriority(List<String> firstPriority) {
        this.firstPriority = firstPriority;
    }

    public List<String> getSecondPriority() {
        return secondPriority;
    }

    public void setSecondPriority(List<String> secondPriority) {
        this.secondPriority = secondPriority;
    }
}
