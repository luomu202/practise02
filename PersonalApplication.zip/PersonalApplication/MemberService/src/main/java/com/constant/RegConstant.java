package com.constant;

public interface RegConstant {

    String ADDRESS_REG = "^[0-9a-z]{1,32}$";
}
