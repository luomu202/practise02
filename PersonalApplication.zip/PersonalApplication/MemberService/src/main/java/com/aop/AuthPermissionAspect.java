package com.aop;

import com.annoation.AuthPermission;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Component
@Aspect
public class AuthPermissionAspect {

    @Pointcut(value = "@annotation(authPermission)")
    public void checkAuth(AuthPermission authPermission) {
    }

    @Around("checkAuth(authPermission)")
    public Object doAround(ProceedingJoinPoint jp,AuthPermission authPermission) throws Throwable {
        Map<String, Object> parameterMap = getCheckParams(jp);
        verifyExist(authPermission,jp);
        return jp.proceed();
    }

    private Map<String, Object> getCheckParams(ProceedingJoinPoint jp) {
        Map<String, Object> parameterMap = new HashMap<>();
        Object[] args = jp.getArgs();
        MethodSignature signature =(MethodSignature) jp.getSignature();
        String[] names = signature.getParameterNames();
        for (int i = 0; i < names.length; i++){
            String pn = names[i];
            parameterMap.put(pn, args[i]);
        }
        return parameterMap;
    }

    private void verifyExist(AuthPermission authPermission, ProceedingJoinPoint jp) {

    }
}
