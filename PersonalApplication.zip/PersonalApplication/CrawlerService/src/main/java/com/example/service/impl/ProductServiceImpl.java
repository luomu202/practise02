package com.example.service.impl;

import com.example.dao.standard.AnimeDao;
import com.example.dao.standard.ProductDao;
import com.example.dao.standard.ProductTaohuaDao;
import com.example.dao.standard.TeacherDao;
import com.example.module.AnimeModule;
import com.example.module.ProductItem;
import com.example.module.ProductModule;
import com.example.service.ProductService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static com.example.utils.CommonUtils.generateUuid;

@Service
@Log4j2
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductDao productDao;

    @Autowired
    private ProductTaohuaDao productTaohuaDao;

    @Autowired
    private TeacherDao teacherDao;

    @Autowired
    private AnimeDao animeDao;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String saveAnime(ProductItem productItem) {
        String animeId = generateUuid();
        String name = productItem.getLicence();
        AnimeModule animeModule = new AnimeModule();
        int count = animeDao.selectCountByName(name);
        if (count != 0) {
            log.info("anime is duplicate name "+name);
            return null;
        }
        animeModule.setId(animeId)
                .setName(name)
                .setType(productItem.getType())
                .setSize(productItem.getSize())
                .setCavalry(productItem.getCavalry())
                .setPublishTime(productItem.getPubTime())
                .setUrl(productItem.getPageUrl());
        animeDao.saveAnime(animeModule);
        log.info("create anime success");
        return animeId;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String saveProductByType(ProductItem productItem, String type) {
        String productId = generateUuid();
        String teacherId = productItem.getTeacherId();
        ProductModule productModule = new ProductModule();
        productModule.setId(productId)
                .setDescription(productItem.getDescription())
                .setLicence(productItem.getLicence())
                .setTitle(productItem.getTitle())
                .setType(productItem.getType())
                .setSize(productItem.getSize())
                .setCavalry(productItem.getCavalry())
                .setPublishTime(productItem.getPubTime())
                .setTeacherId(teacherId)
                .setUrl(productItem.getPageUrl());
        int productCount = productTaohuaDao.selectCountByLicence(productItem.getLicence());
        if (productCount != 0) {
            log.info("product is duplicate licence "+productModule.getLicence());
            return null;
        }
        productDao.insertNewProductByType(productModule,type);
        //更新作品数量
        teacherDao.updateTeacherTimes(teacherId);
        return productId;
    }
}
