package com.domain;

import com.util.DateUtils;

import java.util.Date;

/**
 * 实名认证表
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public class UserDo {

    private String id;
    private String name;
    private String identityCard;
    private int gender;
    private String email;
    private String iphone;
    private String address;
    private int level;
    private String type;
    private Date createTime;
    private Date updateTime;
    private int status;
}
