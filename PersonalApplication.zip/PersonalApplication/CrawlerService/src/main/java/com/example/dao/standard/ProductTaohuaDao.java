package com.example.dao.standard;

import com.example.module.ProductModule;
import org.apache.ibatis.annotations.Param;

public interface ProductTaohuaDao {

    void insertNewProduct(ProductModule productModule);

    int selectCountByLicence(@Param("licence") String licence);

}
