package com.example.task;

import com.example.enums.PageTypes;
import com.example.factory.MyPageProcessorFactory;
import com.example.utils.BeanTools;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.processor.PageProcessor;

import static com.example.constant.RegexConstant.*;
import static com.example.utils.CommonUtils.*;

@Log4j2
@Component
public class JobProcessor implements PageProcessor {

    @Autowired
    private ProductPipeline productPipeline;

    @Autowired
    private MyPageProcessorFactory<Page> myPageProcessorFactory;

    private static Site site = Site.me()
            .setCharset("utf-8")
            .setTimeOut(10 * 1000)
            .setRetrySleepTime(3000)
            .setRetryTimes(3);

    @Override
    public Site getSite() {
        return site;
    }

    @Override
    public void process(Page page) {
        String url = page.getUrl().toString();
        String type = "";
        if (match(PING_URL_REGEX, url)) {
            type = PageTypes.PINGSE.getName();
        } else if (match(TAOHUA_URL_REGEX, url)) {
            type = PageTypes.TAOHUA.getName();
        } else if (match(BAR_URL_REGEX,url)) {
            type = PageTypes.BAR.getName();
        }
        MyPageProcessorFactory<Page> processorFactory = BeanTools.getBean(MyPageProcessorFactory.class);
        processorFactory.getInstance(type).process(page);
    }

    public void startProcess(String... args) {
        Spider.create(new JobProcessor())
                .addUrl(args)
                .addPipeline(productPipeline)
                .thread(100)
                .run();
//                .setScheduler(new QueueScheduler().setDuplicateRemover(new BloomFilterDuplicateRemover(10000000)));//设置布隆去重过滤器，指定最多对1000万数据进行去重操作

    }
}
