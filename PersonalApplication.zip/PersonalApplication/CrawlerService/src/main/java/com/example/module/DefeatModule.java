package com.example.module;

import java.util.Date;

public class DefeatModule {

    private String id;
    private String url;
    private int retry=0;
    private Date createTime;
    private Date updateTime;
    private int status = 1;

    public String getId() {
        return id;
    }

    public DefeatModule setId(String id) {
        this.id = id;
        return this;
    }

    public String getUrl() {
        return url;
    }

    public DefeatModule setUrl(String url) {
        this.url = url;
        return this;
    }

    public int getRetry() {
        return retry;
    }

    public DefeatModule setRetry(int retry) {
        this.retry = retry;
        return this;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public DefeatModule setCreateTime(Date createTime) {
        this.createTime = createTime;
        return this;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public DefeatModule setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
        return this;
    }

    public int getStatus() {
        return status;
    }

    public DefeatModule setStatus(int status) {
        this.status = status;
        return this;
    }
}
