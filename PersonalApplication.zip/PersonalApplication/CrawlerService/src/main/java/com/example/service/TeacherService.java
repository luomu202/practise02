package com.example.service;

import com.example.module.ProductItem;
import com.example.module.TeacherDelayQueueModule;
import com.example.module.TeacherModule;

import java.util.List;
import java.util.concurrent.DelayQueue;

public interface TeacherService {

    String saveTeacher(ProductItem productItem);

    List<TeacherModule> getPrepareTeacherList();

    void setTeacherPriority(DelayQueue<TeacherDelayQueueModule> queue) throws InterruptedException;

}
