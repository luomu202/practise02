package com.example.module;

import lombok.Data;

import java.io.Serializable;

@Data
public class Response<T> implements Serializable {

    private static final long serialVersionUID = 6191311937908792019L;
    private String status;
    private T result;
    private Error error;

}
