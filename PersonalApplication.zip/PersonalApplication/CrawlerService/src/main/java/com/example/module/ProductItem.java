package com.example.module;



import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProductItem implements Serializable {

    private String description;
    private String teacherId;
    private String teacher;
    private String licence;
    private String title;
    private String type;
    private String size;
    private int cavalry;
    private List<String> imageList =new ArrayList<>();
    private String seedUrl;
    private String pageUrl;

    public String getPageUrl() {
        return pageUrl;
    }

    public ProductItem setPageUrl(String pageUrl) {
        this.pageUrl = pageUrl;
        return this;
    }

    public String getSeedUrl() {
        return seedUrl;
    }

    public ProductItem setSeedUrl(String seedUrl) {
        this.seedUrl = seedUrl;
        return this;
    }

    private Date pubTime;

    public String getDescription() {
        return description;
    }

    public ProductItem setDescription(String description) {
        if (StringUtils.isEmpty(description)) {
            teacher = "未知";
        }
        this.description = description;
        return this;
    }

    public String getTeacher() {
        return teacher;
    }

    public ProductItem setTeacher(String teacher) {
        if (StringUtils.isEmpty(teacher)) {
            teacher = "未知";
        }
        this.teacher = teacher;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public ProductItem setTitle(String title) {
        this.title = title;
        return this;
    }

    public String getLicence() {
        return licence;
    }

    public ProductItem setLicence(String licence) {
        this.licence = licence;
        return this;
    }

    public String getTeacherId() {
        return teacherId;
    }

    public ProductItem setTeacherId(String teacherId) {
        this.teacherId = teacherId;
        return this;
    }

    public String getType() {
        return type;
    }

    public ProductItem setType(String type) {
        this.type = type;
        return this;
    }

    public String getSize() {
        return size;
    }

    public ProductItem setSize(String size) {
        this.size = size;
        return this;
    }

    public int getCavalry() {
        return cavalry;
    }

    public ProductItem setCavalry(int cavalry) {
        this.cavalry = cavalry;
        return this;
    }

    public List<String> getImageList() {
        return imageList;
    }

    public ProductItem setImageList(List<String> imageList) {
        this.imageList = imageList;
        return this;
    }

    public Date getPubTime() {
        return pubTime;
    }

    public ProductItem setPubTime(Date pubTime) {
        this.pubTime = pubTime;
        return this;
    }
}
