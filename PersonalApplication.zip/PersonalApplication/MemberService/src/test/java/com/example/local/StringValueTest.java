package com.example.local;

import org.junit.Test;


public class StringValueTest {
    @Test
    public void parseString() {
        String init = "【影片名稱】：HEYZO-2477婚約者をネトラレ！～同窓会でお持ち帰りされちゃった～–白杞りり";
        String substring = init.substring(7);
        System.out.println(init);
    }

}
