package com.dao;

import com.domain.AccountDo;
import com.module.CustomerModel;
import com.module.LoginModel;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDao {

    int queryUserNameCount(@Param("name") String name);

    void createUser(CustomerModel customerModel);

    void createAccount(AccountDo accountDo);
}
