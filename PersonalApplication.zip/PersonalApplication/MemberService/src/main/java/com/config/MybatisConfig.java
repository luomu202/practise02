package com.config;

import org.apache.commons.dbcp2.BasicDataSource;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;

@Component
@MapperScan("com.dao")
public class MybatisConfig {

    @Autowired
    private ApplicationConfig applicationConfig;

    @Bean
    public DataSource getDataSource() {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setDriverClassName(applicationConfig.getDriverClass());
        dataSource.setUrl(applicationConfig.getSqlUrl());
        dataSource.setUsername(applicationConfig.getSqlUserName());
        dataSource.setPassword(applicationConfig.getSqlPassword());
        return dataSource;
    }
//
//    @Bean(name = "sqlSessionFactory")
//    public SqlSessionFactoryBean getSqlSessionFactory() throws IOException {
////        SqlSessionFactory SqlSessionFactory = new DefaultSqlSessionFactory();
//        MybatisConfig2 MybatisConfig2 = new MybatisConfig2();
//        SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
//        //Mybatis的参数配置
////        sqlSessionFactoryBean.setConfigLocation(new ClassPathResource("mybatis-com.config.xml"));
//        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
//        //启用Mybatis的全部xml文件，就不需要一个个去打开
//        String packageSerchPath = PathMatchingResourcePatternResolver.CLASSPATH_ALL_URL_PREFIX + "/mapper/**.xml";
//        sqlSessionFactoryBean.setMapperLocations(resolver.getResources(packageSerchPath));
////        sqlSessionFactoryBean.setDataSource(MybatisConfig2.getDataSource());
//        //实体类所在的包
//        sqlSessionFactoryBean.setTypeAliasesPackage("com.dao");
//        return sqlSessionFactoryBean;
//    }

}
