package com.renss.spring.aop.privilege.annotation;

import java.lang.reflect.Method;

/**
 * 注解解析器
 * @author renss
 * @date 2017-09-13
 */
public class AnnotationParse {
	public static String[] parse(Method method){
		//检测方法上是否有 @PrivilegeInfo 注解，有则返回注解中的value信息，没有则返回空
		if(method.isAnnotationPresent(PrivilegeInfo.class)){
			PrivilegeInfo privailegeInfo = method.getAnnotation(PrivilegeInfo.class);
			String[] privaileges = privailegeInfo.value();
			return privaileges;
		}
		return null;
	}
}
