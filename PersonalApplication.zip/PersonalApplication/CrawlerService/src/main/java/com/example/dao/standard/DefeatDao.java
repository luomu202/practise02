package com.example.dao.standard;

import com.example.module.DefeatModule;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DefeatDao {
    void insertNewPage(DefeatModule defeatModule);

    int getCountByurl(@Param("url") String pageUrl);

    int updateRetryTimes(@Param("url") String pageUrl);

    void updateDefeatStatus(@Param("urls") List<String> urls, @Param("status") Integer status);

    List<String> getDefeatRecord();
}
