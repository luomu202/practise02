package com.module;

import lombok.Data;

@Data
public class TeacherModel {
    private String id;
    private String name;
    private int count;
    private String nation;
    private int status;

    public TeacherModel() {
    }

    public TeacherModel(String id, String name, int count, String nation, int status) {
        this.id = id;
        this.name = name;
        this.count = count;
        this.nation = nation;
        this.status = status;
    }
}
