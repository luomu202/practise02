package com.util;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MathUtils {

    /**
     * 获取两个数之间的随机数
     * @param begin
     * @param end
     * @return
     */
    public static double getRandomaDouble(Double begin, Double end) {
        Double rtn = begin + (Double)(Math.random() * (end - begin));
        if (rtn .equals(begin)  || rtn.equals(end)) {
            return getRandomaDouble(begin, end);
        }
        return rtn;
    }
    /**
     * 获取两个数之间的随机数
     * @param begin
     * @param end
     * @return
     */
    public static long getRandomaLong(long begin,long end) {
        long rtn = begin + (long)(Math.random() * (end - begin));
        if (rtn ==begin  || rtn==end) {
            return getRandomaLong(begin, end);
        }
        return rtn;
    }

    /**
     *
     * @param d
     * @return
     */
    public static String getRealStringOfDouble(Double d) {
        String ds = d.toString();
        boolean b = ds.contains("E");
        int iop = ds.indexOf(".");
        if (b) {
            int indexOfe = ds.indexOf("E");
            BigInteger bigInteger = new BigInteger(ds.substring(iop + BigInteger.ONE.intValue()),indexOfe);
            int pow = Integer.parseInt(ds.substring(indexOfe + BigInteger.ONE.intValue()));
            int xsLength = bigInteger.toByteArray().length;
            int scala = Math.max(xsLength - pow, 0);
            ds = String.format("%." + (scala - 1) + "f", d);
        }else {
            Pattern p = Pattern.compile(".0$");
            Matcher matcher = p.matcher(ds);
            if (matcher.find()) {
                ds = ds.replace(".0", "");
            }
        }
        return ds;
    }
}
