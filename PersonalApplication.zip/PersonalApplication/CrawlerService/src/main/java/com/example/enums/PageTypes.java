package com.example.enums;

public enum PageTypes {
    /**
     *
     */
    PINGSE,

    TAOHUA,

    PINGSE_ANIME,

    BAR;

    public String getName() {
        return name().toLowerCase();
    }
}
