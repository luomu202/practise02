package com.service;

import com.module.LoginModel;
import com.module.Response;

import javax.servlet.http.HttpServletRequest;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public interface LoginService {
    LoginModel loginByUserName(LoginModel loginModel);

    Boolean validationName(String userName);

    Object checkPermission(HttpServletRequest request, String cookie, String checkUrl);
}
