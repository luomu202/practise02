package com.controller;

import com.annoation.AuthPermission;
import com.dao.TeacherDao;
import com.enums.Roles;
import com.module.Response;
import com.service.TeachserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@Slf4j
public class TeacherController extends BaseController {

    @Autowired
    private TeachserService teachserService;

    @Autowired
    private TeacherDao teacherDao;


    @RequestMapping(value = "/teacher/all",method = RequestMethod.GET)
    @ResponseBody
    @AuthPermission(role = Roles.TEACHER,check = true)
    public Response getTeacherList() {
        List<Map> teachserList = teachserService.getTeacherList();
        log.info("get teacher list success "+teachserList);
        return getSuccessResponse(teachserList);
    }

    @RequestMapping(value = "/teacher/all/file",method = RequestMethod.GET)
    @AuthPermission(role = Roles.TEACHER,check = true)
    public void getTeacherListFile() {
        log.info("get teacherList File");
        teachserService.getTeacherListFile();
    }
}
