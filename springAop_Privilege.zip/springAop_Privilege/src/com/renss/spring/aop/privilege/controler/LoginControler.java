package com.renss.spring.aop.privilege.controler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.renss.spring.aop.privilege.domain.Person;
import com.renss.spring.aop.privilege.domain.Privilege;
import com.renss.spring.aop.privilege.util.ServletUtil;

@Controller
@RequestMapping("/login")
public class LoginControler {
	
	@RequestMapping
	public ModelAndView login(@ModelAttribute("person") Person person,HttpServletRequest request,
			HttpServletResponse response){
		ModelAndView mv = new ModelAndView("login");
		if(!"admin".equals(person.getName()) || !"123456".equals(person.getPassword())){
			if(!"renss".equals(person.getName()) || !"123456".equals(person.getPassword())){
				mv.addObject("msg", "用户名或密码错误！");
				return mv;
			}
		}
		//加载权限
		person = addPrivileges(person);
		request.getSession().setAttribute("person", person);
		try {
			response.sendRedirect(request.getContextPath() + "/index.jsp");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private Person addPrivileges(Person person) {
		List<Privilege> privileges = new ArrayList<Privilege>();
		if("admin".equals(person.getName())){
			Privilege security = new Privilege("security");
			Privilege save = new Privilege("save");
			Privilege update = new Privilege("update");
			privileges.add(security);
			privileges.add(save);
			privileges.add(update);
		}else{
			Privilege save = new Privilege("save");
			Privilege update = new Privilege("update");
			privileges.add(save);
			privileges.add(update);
		}
		person.setPrivileges(privileges);
		return person;
	}
}
