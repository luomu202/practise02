package com.example.factory;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Log4j2
@Component
public class MyPageProcessorFactory<T> {
    @Autowired
    Map<String, MyPageProcessor<T>> pageProcessorMap = new ConcurrentHashMap<>();

    public  MyPageProcessor<T> getInstance(String type) {
        MyPageProcessor<T> myPageProcessor = pageProcessorMap.get(type);
        if (myPageProcessor == null) {
            log.error("get pageProcessor instance failed");
            return null;
        }
        return myPageProcessor;
    }
}
