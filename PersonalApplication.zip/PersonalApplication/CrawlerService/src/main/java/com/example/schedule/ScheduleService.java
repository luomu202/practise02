package com.example.schedule;

import com.example.async.AsyncExecuteHandler;
import com.example.module.TeacherModule;
import com.example.service.ProductShardingService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Log4j2
public class ScheduleService {


    @Autowired
    private AsyncExecuteHandler asyncExecuteHandler;

    @Autowired
    private ProductShardingService productShardingService;


    /**
     * initialDelay当任务启动后，等等多久执行方法
     * fixedDelay每个多久执行方法
     *
     * @Scheduled(cron = "0 0 0/1 * * ?")
     */
//    @Scheduled(initialDelay = 1000, fixedDelay = 5 * 60 * 60 * 1000)
    public void teacherPrioritySchedule() {
        log.info("schedule update teacher priority start");
        asyncExecuteHandler.setTeacherPriority();
    }

    /**
     * initialDelay当任务启动后，等等多久执行方法
     * fixedDelay每个多久执行方法
     *
     * @Scheduled(cron = "0 0 0/1 * * ?")
     */
//    @Scheduled(initialDelay = 1000, fixedDelay = 5 * 60 * 60 * 1000)
    public void failedPageProcessSchedule() {
        log.info("schedule update teacher priority start");
        asyncExecuteHandler.failedPageProcess();
    }

//    @Scheduled(initialDelay = 1000, fixedDelay = 5 * 60 * 60 * 1000)
    public void shardingTest() {
        log.info("schedule update teacher priority start");
        List<TeacherModule> list = productShardingService.selectTeacherList();
        System.out.println("123");
    }
}
