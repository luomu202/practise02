package com.config;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.log4j.Log4j2;
import org.crazycake.shiro.RedisManager;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

@Configuration
@Log4j2
public class JedisHandler  {
    @Value("${redis.address}")
    private String redisAddress;
    @Value("${redis.port}")
    private int redisPort;
    @Value("${redis.auth}")
    private String redisAuth;
    @Value("${redis.max.active}")
    private int maxActive;
    @Value("${redis.max.idle}")
    private int maxIdle;
    @Value("${redis.timeout}")
    private int timeOut;

    private static JedisPool jedisPool =null;

    private static JedisHandler jedisHandler = new JedisHandler();

    public JedisHandler() {
    }

    public static JedisHandler getInstance() {
        return jedisHandler;
    }
    /**
     * 初始化redis连接
     * @return
     */
    @Bean
    public JedisPoolConfig jedisPoolConfig() {
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxTotal(maxActive);
        config.setMaxIdle(maxIdle);
        config.setMaxWaitMillis(timeOut);
        config.setTestOnBorrow(true);
        jedisPool = new JedisPool(config, redisAddress);
        return config;
    }

    @Bean
    public JedisConnectionFactory jedisConnectionFactory(JedisPoolConfig jedisPoolConfig) {
        JedisConnectionFactory factory = new JedisConnectionFactory(jedisPoolConfig);
        //连接池
        factory.setPoolConfig(jedisPoolConfig);
        factory.setHostName(redisAddress);
        factory.setPort(redisPort);
//        factory.setPassword(redisAuth);
        factory.setTimeout(timeOut);
        return factory;
    }

    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<String, Object>();
        //替换默认序列化
        Jackson2JsonRedisSerializer js = new Jackson2JsonRedisSerializer(Object.class);
        ObjectMapper om = new ObjectMapper();
        om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        js.setObjectMapper(om);
        //设置value的学序列化规则和key序列化规则
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.setValueSerializer(js);
        redisTemplate.setConnectionFactory(redisConnectionFactory);
        return redisTemplate;
    }


    public synchronized Jedis getJedis() {
        try {
            if (jedisPool != null) {
                Jedis resource = jedisPool.getResource();
                return resource;
            } else {
                log.error("get redis failed reason redisPool is null");
                return null;
            }
        } catch (Exception exception) {
            log.error("get redis failed reason "+exception.getMessage());
            return null;
        }
    }

    public synchronized static void returnJedis(Jedis jedis) {
        if (jedis != null) {
            jedis.close();
            log.info("return redis success");
        }
        log.error("return redis failed reason redis is null");
    }


}
