package com.example.config;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.sql.DataSource;
import java.sql.SQLException;

@Configuration
@MapperScan(basePackages = "com.example.dao.standard",sqlSessionTemplateRef = "sqlSessionTemplateStandard")
public class MybatisStandardConfig {

    @Autowired
    private DataSourceConfig dataSourceConfig;

    @Primary
    @Bean(name = "standardDataSourceProperties")
    @ConfigurationProperties(prefix = "spring.datasource.standard")
    public DataSourceProperties standardDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean("standardDataSource")
    @Primary
    public DataSource getDataSource(
            @Qualifier("standardDataSourceProperties") DataSourceProperties dataSourceProperties
    ) throws SQLException {
        return dataSourceConfig.getAtomikosDataSourceBean(dataSourceProperties, "standardDataSource");
    }

    @Bean("sqlSessionFactoryStandard")
    public SqlSessionFactory sqlSessionFactory(@Qualifier("standardDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean sfb = new SqlSessionFactoryBean();
        sfb.setDataSource(dataSource);
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        sfb.setMapperLocations(resolver.getResources("classpath:/mapper/**.xml"));
        sfb.setConfigLocation(resolver.getResource("classpath:mybatis-config.xml"));
        return sfb.getObject();
    }

    @Bean("sqlSessionTemplateStandard")
    public SqlSessionTemplate standardSqlSessionTemplate(
            @Qualifier("sqlSessionFactoryStandard") SqlSessionFactory sqlSessionFactory
    ) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }
}
