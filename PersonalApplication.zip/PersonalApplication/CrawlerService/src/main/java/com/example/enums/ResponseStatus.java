package com.example.enums;

public enum ResponseStatus {
    SUCCESS,
    FAILED;
    public  String getName() {
        return this.name().toLowerCase();
    }
}
