package com.example.module;

import java.util.Date;

public class AttachModule {


    private String id;
    private String productId;
    private String md5;
    private String location;
    private String url;
    private int fileType;
    private Date createTime;
    private Date updateTime;
    private int status = 1;

    public String getId() {
        return id;
    }

    public AttachModule setId(String id) {
        this.id = id;
        return this;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public AttachModule setCreateTime(Date createTime) {
        this.createTime = createTime;
        return this;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public AttachModule setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
        return this;
    }

    public int getStatus() {
        return status;
    }

    public AttachModule setStatus(int status) {
        this.status = status;
        return this;
    }

    public String getProductId() {
        return productId;
    }

    public AttachModule setProductId(String productId) {
        this.productId = productId;
        return this;
    }

    public String getMd5() {
        return md5;
    }

    public AttachModule setMd5(String md5) {
        this.md5 = md5;
        return this;
    }

    public String getLocation() {
        return location;
    }

    public AttachModule setLocation(String location) {
        this.location = location;
        return this;
    }

    public String getUrl() {
        return url;
    }

    public AttachModule setUrl(String url) {
        this.url = url;
        return this;
    }

    public int getFileType() {
        return fileType;
    }

    public AttachModule setFileType(int fileType) {
        this.fileType = fileType;
        return this;
    }
}
