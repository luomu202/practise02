package com.example.service.impl;

import com.example.dao.standard.TeacherDao;
import com.example.module.ProductItem;
import com.example.module.TeacherDelayQueueModule;
import com.example.module.TeacherModule;
import com.example.service.TeacherService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.concurrent.DelayQueue;

import static com.example.utils.CommonUtils.generateUuid;

@Service
@Log4j2
public class TeacherServiceImpl implements TeacherService {

    @Autowired
    private TeacherDao teacherDao;


    @Override
    @Transactional
    public String saveTeacher(ProductItem productItem) {
        String teacherId = generateUuid();
        //插入教师
        TeacherModule teacherModule = new TeacherModule();
        teacherModule.setId(teacherId)
                .setName(productItem.getTeacher());
        String oldTeacherId = teacherDao.selectTeacherIdByName(productItem.getTeacher());
        if (oldTeacherId == null) {
            teacherDao.insetNewTeacher(teacherModule);
            log.info("insert new teacher teacher name "+productItem.getTeacher()+" page "+productItem.getPageUrl());
        } else {
            teacherId = oldTeacherId;
            log.info("teacher is duplicate teacherId "+teacherId);
        }
        return teacherId;
    }

    @Override
    @Transactional(readOnly = true)
    public List<TeacherModule> getPrepareTeacherList() {
        return teacherDao.getPrepareTeacherList();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void setTeacherPriority(DelayQueue<TeacherDelayQueueModule> queue) throws InterruptedException {
        while (!queue.isEmpty()) {
            TeacherDelayQueueModule teacherDelayQueueModule = queue.take();
            log.info("get element time " + System.currentTimeMillis());
            teacherDao.updateTeacherPriority(teacherDelayQueueModule.getId(),teacherDelayQueueModule.getPriority());
            log.info("update teacher success teacherId "+teacherDelayQueueModule.getId());
        }
        log.info("async set teacher priority task end");
    }
}
