package com.service.impl;


import com.config.DefaultRedisManager;
import com.config.JedisHandler;
import com.dao.UserDao;
import com.domain.AccountDo;
import com.module.LoginModel;
import com.module.ServiceException;
import com.module.CustomerModel;
import com.service.UserService;
import com.util.CommonUtils;
import com.util.MD5Utils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Jedis;

@Service
@Slf4j
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    @Override
    public void createUser(CustomerModel customerModel) throws ServiceException {
        //重名校验
        Jedis jedis = JedisHandler.getInstance().getJedis();
        String set = jedis.set("12123123", "123123123");
        int count =  userDao.queryUserNameCount(customerModel.getName());
        if (count != 0) {
            log.error("user name is exist");
            throw new ServiceException("用户名已经存在");
        }

        customerModel.setId(CommonUtils.genrerateUuid());
        userDao.createUser(customerModel);

    }

    @Override
    public void createAccount(LoginModel loginModel) {
        AccountDo accountDo = new AccountDo(loginModel);
        String salt = CommonUtils.genrerateUuid();
        accountDo.setSalt(salt);
        String loginPassword = loginModel.getPassword();
        String password = MD5Utils.getPassword(salt, loginPassword);
        accountDo.setPassword(password);
        userDao.createAccount(accountDo);
        log.info("create account succeed");
    }
}
