package com.example.module;

import java.util.Date;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
public class AnimeModule {
    private String id;
    private String name;
    private String url;
    private String type;
    private String size;
    private int cavalry;
    private Date publishTime;
    private Date createTime;
    private Date updateTime;
    private int status = 1;

    public String getId() {
        return id;
    }

    public AnimeModule setId(String id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public AnimeModule setName(String name) {
        this.name = name;
        return this;
    }

    public String getUrl() {
        return url;
    }

    public AnimeModule setUrl(String url) {
        this.url = url;
        return this;
    }

    public String getType() {
        return type;
    }

    public AnimeModule setType(String type) {
        this.type = type;
        return this;
    }

    public String getSize() {
        return size;
    }

    public AnimeModule setSize(String size) {
        this.size = size;
        return this;
    }

    public int getCavalry() {
        return cavalry;
    }

    public AnimeModule setCavalry(int cavalry) {
        this.cavalry = cavalry;
        return this;
    }

    public Date getPublishTime() {
        return publishTime;
    }

    public AnimeModule setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
        return this;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public AnimeModule setCreateTime(Date createTime) {
        this.createTime = createTime;
        return this;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public AnimeModule setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
        return this;
    }

    public int getStatus() {
        return status;
    }

    public AnimeModule setStatus(int status) {
        this.status = status;
        return this;
    }
}
