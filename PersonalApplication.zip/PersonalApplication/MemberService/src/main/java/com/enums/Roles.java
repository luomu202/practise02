package com.enums;

import org.omg.CORBA.PUBLIC_MEMBER;

public enum Roles{
    /**
     * 教师
     */
    TEACHER,
    /**
     * 会员
     */
    TOURIST,

    PURCHASER,

    MERCHANT;

    public String getName() {
        return name().toLowerCase();
    }

}
