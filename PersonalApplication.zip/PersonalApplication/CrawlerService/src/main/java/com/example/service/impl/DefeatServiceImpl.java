package com.example.service.impl;

import com.example.dao.standard.DefeatDao;
import com.example.module.DefeatModule;
import com.example.service.DefeatService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static com.example.utils.CommonUtils.generateUuid;

@Service
@Log4j2
public class DefeatServiceImpl implements DefeatService {

    @Autowired
    private DefeatDao defeatDao;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void createDefeatRecord(String pageUrl) {
        log.error("create product fail");
        int count = defeatDao.getCountByurl(pageUrl);
        if (count != 0) {
            log.info("defeat is already exist licence "+pageUrl);
            return ;
        }
        DefeatModule defeatModule = new DefeatModule();
        defeatModule.setId(generateUuid())
                .setUrl(pageUrl);
        defeatDao.insertNewPage(defeatModule);
        log.info("create defeat page success");
    }

    @Override
    public void insertNewPage(DefeatModule defeatModule) {
        defeatDao.insertNewPage(defeatModule);
    }

    @Override
    public int updateRetryTimes(String pageUrl) {
        return defeatDao.updateRetryTimes(pageUrl);
    }

    @Override
    public List<String> getDefeateRecord() {
        return defeatDao.getDefeatRecord();
    }

    @Override
    public void setDefeatStatus(List<String> urls,Integer status) {
        defeatDao.updateDefeatStatus(urls,status);
    }
}
