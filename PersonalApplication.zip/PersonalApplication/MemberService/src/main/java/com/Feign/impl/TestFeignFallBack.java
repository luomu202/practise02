package com.Feign.impl;

import com.Feign.TestFeign;
import com.module.Response;
import feign.hystrix.FallbackFactory;

public class TestFeignFallBack implements FallbackFactory<TestFeign> {
//    @Override
//    public Response requestTest(String params, String sign) {
//        return null;
//    }

    @Override
    public TestFeign create(Throwable throwable) {
        return null;
    }
}
