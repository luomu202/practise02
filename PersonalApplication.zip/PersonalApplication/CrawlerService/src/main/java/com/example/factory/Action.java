package com.example.factory;

import org.springframework.stereotype.Component;

@Component
public interface Action<T> {

    void doAction(T t);
}
