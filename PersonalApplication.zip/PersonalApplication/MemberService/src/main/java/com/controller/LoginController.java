package com.controller;

import com.module.LoginModel;
import com.module.Response;
import com.service.LoginService;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * @author luomu
 * @description
 * @date 2018-09-07
 */
@RestController
@RequestMapping("/v1/MemberService")
@Log4j2
public class LoginController extends BaseController {

    @Autowired
    private LoginService loginService;

    /**
     * 用户名登录
     * @param loginModel
     * @param bindingResult
     * @return
     */
    @RequestMapping(value = "/loginByNickName", method = RequestMethod.POST)
    public Response loginByUserName(@Validated @RequestBody LoginModel loginModel, BindingResult bindingResult) {
        if (StringUtils.isEmpty(loginModel.getNickName()) || StringUtils.isEmpty(loginModel.getPassword())) {
            log.error(" loginByUserName nickName or password is empty");
            throw new SecurityException("用户名或密码不能为空");
        }
        return getSuccessResponse(loginService.loginByUserName(loginModel));
    }

    /**
     * 微信公众号登录
     * @param loginModel
     * @param bindingResult
     * @return
     */
    @RequestMapping(value = "/loginByOpenId", method = RequestMethod.POST)
    public Response loginByOpenId(@Validated @RequestBody LoginModel loginModel, BindingResult bindingResult) {
        if (StringUtils.isEmpty(loginModel.getOpenId())) {
            log.error(" loginByOpenId openId is empty");
            throw new SecurityException("");
        }
        return null;
    }

    /**
     * 重名校验
     * @param userName
     * @return
     */
    @RequestMapping(value = "/name/validation", method = RequestMethod.GET)
    public Response validationName(@RequestParam String userName) {
        //TODO 用户名校验,编码解码
        log.info("validation userName duplicated "+userName);
        return getSuccessResponse(loginService.validationName(userName));
    }

//    @RetExclude
//    @ApiOperation(value = "验证权限", notes = "从cookie拿到token去校验，支持传递token参数， 会先验证登录状态")
    @RequestMapping(value="/checkPermission", method=RequestMethod.POST)
    public Response checkPermission(@RequestParam("cookie")String cookie, @RequestParam("checkUrl")String checkUrl) {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        // log.info("Cookie==>" + request.getHeader("Cookie"));
        // log.info("param==>" + cookie);
        return getSuccessResponse(loginService.checkPermission(request, cookie, checkUrl));
    }
}
