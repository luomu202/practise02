package com.example.factory.impl;

import com.example.constant.CommonConstant;
import com.example.constant.RegexConstant;
import com.example.dao.standard.DefeatDao;
import com.example.dao.standard.ProductDao;
import com.example.enums.PageTypes;
import com.example.factory.MyPageProcessor;
import com.example.module.ProductItem;
import com.example.utils.CommonUtils;
import com.example.utils.DateUtils;
import com.example.utils.ExceptionLogUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.selector.Html;
import us.codecraft.webmagic.selector.Selectable;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

@Service("taohua")
@Log4j2
public class TaoHuaProcessor<U, T> extends BaseProcessor implements MyPageProcessor {

    @Autowired
    private ProductDao productDao;

    private volatile Date newPublishTime = new Date();


    @Override
    public void process(Page page) {
        List<Selectable> list = page.getHtml().css("a.s.xst").nodes();
        //判断获取到的集合是否为空
        if (list.size() == 0) {
            // 如果为空，表示这是详情页,解析页面，获取招聘详情信息，保存数据
            this.saveJobInfo(page);
        } else {
            //如果不为空，表示这是列表页,解析出详情页的url地址，放到任务队列中
            for (Selectable selectable : list) {
                //获取url地址
                String jobInfoUrl = selectable.links().toString();
                //把获取到的url地址放到任务队列中
                page.addTargetRequest(jobInfoUrl);
            }
            Date oldPubTime = productDao.selectBeforeGapPubTime(PageTypes.TAOHUA.getName(), CommonConstant.GRP_TIME);
            if (!newPublishTime.before(oldPubTime)) {
                //获取下一页的url
                String bkUrl = page.getHtml().css("a.nxt").nodes().get(0).links().toString();
                //把url放到任务队列中
                page.addTargetRequest(bkUrl);
            }
        }
    }

    //解析页面
    private void saveJobInfo(Page page) {
        //创建招聘详情对象
        ProductItem productItem = new ProductItem();
        //解析页面
        Html html = page.getHtml();
        try {
            //获取页面内容
            Selectable totalContent = html.css("div.t_fsz").nodes().get(0);
            List<Selectable> nodes = html.css("div.pattl p.attnm>a", "href").nodes();
            String textContent = totalContent.css(".t_f", "text").toString();
            if (textContent.contains(CommonConstant.TAOHUA_REJECT_ITEM)) {
                return;
            }
            String[] contentList = textContent.replaceAll("：", "#")
                    .replaceAll(":", "#")
                    .split("#");
            if (contentList.length != 13) {
                throw new RuntimeException("taohu page parse error");
            }
            totalContent.css(".t_f img.zoom", "file").nodes().stream().forEach(i -> {
                productItem.getImageList().add(i.get());
            });
            //获取发布时间
            String pubTime = contentList[9].substring(0, contentList[9].length() - 7);
            Date parsePubTime = DateUtils.getDateFromString(pubTime, "yyyy-MM-dd");
            this.newPublishTime = parsePubTime;
            //获取种子文件地址
            String seedUrl = CommonConstant.TAOHUA_DNS + nodes.get(nodes.size() - 1).get();
            productItem.setDescription(contentList[1].substring(0, contentList[1].length() - 11))
                    .setTeacher(contentList[2].substring(0, contentList[2].length() - 7))
                    .setLicence(contentList[11].substring(0, contentList[11].length() - 7))
                    .setType(contentList[3].substring(0, contentList[3].length() - 7))
                    .setSize(contentList[4].substring(0, contentList[4].length() - 8))
                    .setCavalry(CommonUtils.match(RegexConstant.IS_CAVALRY_REGEX, contentList[8].substring(0, contentList[8].length() - 10)) ? 0 : 1)
                    .setPubTime(parsePubTime)
                    .setSeedUrl(seedUrl)
                    .setPageUrl(page.getUrl().toString());
            //把结果保存起来
            page.putField("productItem", productItem);
        } catch (Exception e) {
            ExceptionLogUtils.dealWithExceptionLog(e);
            handlerDefeatPage(page.getUrl().toString());
        }
    }
}
