package com.example.factory;

import com.example.anno.ActionType;
import com.example.utils.ClassScanner;
import com.google.common.collect.Maps;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class ActionPipelinePro<T> implements BeanFactoryPostProcessor {

    private static final String PACKAGE_LOCATION="com.example.factory";

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
        Map<String,Class<?>> actionMap = Maps.newHashMapWithExpectedSize(3);
        ClassScanner.scan(PACKAGE_LOCATION, ActionType.class).forEach(clazz->{
            ActionType actionType = clazz.getAnnotation(ActionType.class);
            actionMap.put(actionType.value(), clazz);
        });
        PipelineFactory pipelineFactory = new PipelineFactory(actionMap);
        beanFactory.registerSingleton(PipelineFactory.class.getName(),pipelineFactory);
    }
}
