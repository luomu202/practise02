package com.renss.spring.aop.privilege.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.renss.spring.aop.privilege.domain.Person;

public class LoginFilter implements Filter {

	private String[] ignoreUris;

	public void setIgnoreUris(String[] ignoreUris) {
		this.ignoreUris = ignoreUris;
	}

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		if (!(request instanceof HttpServletRequest) || !(response instanceof HttpServletResponse)) {
			throw new ServletException("OncePerRequestFilter just supports HTTP requests");
		}
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		boolean flag = false;
		if(ignoreUris != null && ignoreUris.length > 0){
			String requestUri = httpRequest.getRequestURI();
			for(String uri : ignoreUris){
				if(flag = requestUri.contains(uri)) break;
			}
		}
		if(flag){
			chain.doFilter(httpRequest, httpResponse);
			return;
		}
		Person person = (Person) httpRequest.getSession().getAttribute("person");
		if(person != null){
			httpRequest.setAttribute("respons", httpResponse);
			chain.doFilter(httpRequest, httpResponse);
			return;
		}
		httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.jsp");
	}

	public void init(FilterConfig config) throws ServletException {
		String ignoreUri = config.getInitParameter("ignore");
		ignoreUris = ignoreUri.split(",");
	}

}
